package com.oleo.cpmscripts.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

/** Плоская кнопка в стиле CPM: заливка + тонкая рамка, без ванильного спрайта. */
public class FlatButton extends Button {
	private final int baseColor;
	private final int hoverColor;
	private final int textColor;

	public FlatButton(int x, int y, int w, int h, Component msg, OnPress onPress) {
		this(x, y, w, h, msg, onPress, GuiStyle.BTN, GuiStyle.BTN_HOVER, GuiStyle.TEXT);
	}

	public FlatButton(int x, int y, int w, int h, Component msg, OnPress onPress, int base, int hover, int text) {
		super(x, y, w, h, msg, onPress, Button.DEFAULT_NARRATION);
		this.baseColor = base;
		this.hoverColor = hover;
		this.textColor = text;
	}

	@Override
	public void renderContents(GuiGraphics gg, int mouseX, int mouseY, float partialTick) {
		int c = !this.active ? GuiStyle.BTN_DISABLED : (this.isHoveredOrFocused() ? hoverColor : baseColor);
		int x = getX(), y = getY(), w = getWidth(), h = getHeight();
		gg.fill(x, y, x + w, y + h, c);
		int border = this.isHoveredOrFocused() && this.active ? GuiStyle.ACCENT : GuiStyle.BTN_BORDER;
		gg.fill(x, y, x + w, y + 1, border);
		gg.fill(x, y + h - 1, x + w, y + h, border);
		gg.fill(x, y, x + 1, y + h, border);
		gg.fill(x + w - 1, y, x + w, y + h, border);
		int tc = this.active ? textColor : GuiStyle.MUTED;
		gg.drawCenteredString(Minecraft.getInstance().font, getMessage(), x + w / 2, y + (h - 8) / 2, tc);
	}
}

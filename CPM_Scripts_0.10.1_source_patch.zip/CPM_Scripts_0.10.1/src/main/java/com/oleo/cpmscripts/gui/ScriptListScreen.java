package com.oleo.cpmscripts.gui;

import java.nio.file.Path;
import java.util.List;


import net.fabricmc.loader.api.FabricLoader;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import com.oleo.cpmscripts.CpmScriptsClient;
import com.oleo.cpmscripts.ScriptEngine;

/**
 * Список скриптов: вкл/выкл, редактирование, удаление, reload,
 * добавление .lua через нативное системное окно (как в CPM).
 */
public class ScriptListScreen extends Screen {
	private static final int ROW_H = 24;
	private static final int LIST_W = 340;

	private String pendingDelete; // имя скрипта, ожидающего подтверждения удаления

	public ScriptListScreen() {
		super(Component.literal("CPM Scripts"));
	}

	@Override
	protected void init() {
		int x = this.width / 2 - LIST_W / 2;
		int y = 40;
		List<String[]> infos = ScriptEngine.scriptInfo();
		for (String[] info : infos) {
			String name = info[0];
			boolean en = "1".equals(info[1]);
			boolean graph = name.startsWith("nodes/");
			String label = (graph ? "[граф] " : "") + name + (info[2].isEmpty() ? "" : "  (ошибка)");
			final boolean enF = en;
			final String nameF = name;
			FlatButton toggle = new FlatButton(x + 6, y, LIST_W - 130, 18, Component.literal(label), b -> {
				if (pendingDelete != null) return;
				ScriptEngine.setScriptEnabled(nameF, !enF);
				this.rebuildWidgets();
			}, en ? 0xFF23332E : GuiStyle.BTN, en ? 0xFF2E453D : GuiStyle.BTN_HOVER, en ? GuiStyle.ON : GuiStyle.MUTED);
			addRenderableWidget(toggle);
			addRenderableWidget(new FlatButton(x + LIST_W - 120, y, 38, 18, Component.literal("edit"), b -> {
				if (pendingDelete != null) return;
				if (graph) Minecraft.getInstance().setScreen(new NodeCanvasScreen(this, name.substring("nodes/".length())));
				else Minecraft.getInstance().setScreen(new ScriptEditScreen(this, name));
			}, graph ? 0xFF2E2740 : GuiStyle.BTN, graph ? 0xFF403660 : GuiStyle.BTN_HOVER,
				graph ? GuiStyle.ACCENT : GuiStyle.TEXT));
			addRenderableWidget(new FlatButton(x + LIST_W - 78, y, 34, 18, Component.literal("ren"), b -> {
				if (pendingDelete != null) return;
				Minecraft.getInstance().setScreen(new RenameScreen(this, name));
			}));
			addRenderableWidget(new FlatButton(x + LIST_W - 40, y, 34, 18, Component.literal("del"), b -> {
				if (pendingDelete != null) return;
				pendingDelete = name; // не удаляем сразу — спрашиваем
				this.rebuildWidgets();
			}, 0xFF3A2626, 0xFF4E3030, GuiStyle.ERROR));
			y += ROW_H;
			if (y > this.height - 112) break; // резерв для двух нижних рядов кнопок
		}

		int by = this.height - 58;
		addRenderableWidget(new FlatButton(x + 6, by, 70, 18, Component.literal("Reload"), b -> {
			ScriptEngine.reload();
			this.rebuildWidgets();
		}));
		addRenderableWidget(new FlatButton(x + 82, by, 90, 18,
			Component.literal(ScriptEngine.isEnabled() ? "Scripts: ON" : "Scripts: OFF"), b -> {
			ScriptEngine.setEnabled(!ScriptEngine.isEnabled());
			this.rebuildWidgets();
		}, ScriptEngine.isEnabled() ? 0xFF23332E : 0xFF3A2626, GuiStyle.BTN_HOVER,
			ScriptEngine.isEnabled() ? GuiStyle.ON : GuiStyle.ERROR));
		addRenderableWidget(new FlatButton(x + 178, by, 46, 18, Component.literal("New"), b ->
			Minecraft.getInstance().setScreen(new ScriptEditScreen(this, "new_" + System.currentTimeMillis() % 100000 + ".lua"))));
		addRenderableWidget(new FlatButton(x + 178, by - 22, 112, 18, Component.literal("New graph"), b ->
			Minecraft.getInstance().setScreen(new NodeCanvasScreen(this, "graph_" + System.currentTimeMillis() % 100000 + ".json"))));
		addRenderableWidget(new FlatButton(x + 230, by, 64, 18, Component.literal("Add file"), b -> addFile(),
			0xFF24303C, 0xFF31445A, GuiStyle.ACCENT));
		addRenderableWidget(new FlatButton(x + LIST_W - 40, by, 40, 18, Component.literal("Done"), b -> onClose()));

		// диалог подтверждения удаления (поверх всего)
		if (pendingDelete != null) {
			int dw = 220, dx = this.width / 2 - dw / 2, dy = this.height / 2 - 30;
			addRenderableWidget(new FlatButton(dx + 14, dy + 34, 90, 18, Component.literal("Удалить"), b -> {
				ScriptEngine.deleteScript(pendingDelete);
				pendingDelete = null;
				this.rebuildWidgets();
			}, 0xFF5A2A2A, 0xFF7A3636, GuiStyle.ERROR));
			addRenderableWidget(new FlatButton(dx + dw - 104, dy + 34, 90, 18, Component.literal("Отмена"), b -> {
				pendingDelete = null;
				this.rebuildWidgets();
			}));
		}
	}

	/** Родное окно выбора файла CPM; если CPM не загружен — внутриигровой выбор. */
	private void addFile() {
		if (FabricLoader.getInstance().isModLoaded("cpm")) {
			try {
				Minecraft.getInstance().setScreen(new CpmFilePickScreen(this));
				return;
			} catch (Throwable ignored) {}
		}
		Minecraft.getInstance().setScreen(new FilePickScreen(this));
	}

	@Override
	public void render(GuiGraphics gg, int mouseX, int mouseY, float partialTick) {
		GuiStyle.background(gg, this.width, this.height);
		GuiStyle.header(gg, this.font, this.width, "CPM Scripts", ScriptEngine.getScriptsDir().toString());

		int x = this.width / 2 - LIST_W / 2;
		int y0 = 36;
		int rows = Math.min(ScriptEngine.scriptInfo().size(), (this.height - 152) / ROW_H + 1);
		GuiStyle.panel(gg, x, y0, LIST_W, Math.max(rows, 1) * ROW_H + 8);
		GuiStyle.panel(gg, x, this.height - 62, LIST_W, 26);

		// оверлей подтверждения удаления: затемнение + панель до виджетов, текст после
		if (pendingDelete != null) {
			gg.fill(0, 0, this.width, this.height, 0xA0000000);
			int dw = 220, dx = this.width / 2 - dw / 2, dy = this.height / 2 - 30;
			GuiStyle.panel(gg, dx, dy, dw, 60);
		}

		super.render(gg, mouseX, mouseY, partialTick);

		if (pendingDelete != null) {
			gg.drawCenteredString(this.font, "Удалить " + pendingDelete + "?", this.width / 2, this.height / 2 - 18, GuiStyle.TEXT);
		}

		if (ScriptEngine.scriptInfo().isEmpty()) {
			gg.drawCenteredString(this.font, "Нет скриптов — New или Add file", this.width / 2, y0 + 10, GuiStyle.MUTED);
		}

		// ошибки загрузки красным под строкой скрипта
		int y = 40;
		for (String[] info : ScriptEngine.scriptInfo()) {
			if (!info[2].isEmpty()) {
				String err = info[2];
				if (err.length() > 55) err = err.substring(0, 55);
				gg.drawString(this.font, err, x + 10, y + 18, GuiStyle.ERROR);
			}
			y += ROW_H;
			if (y > this.height - 112) break;
		}
	}

	@Override
	public void onClose() {
		Minecraft.getInstance().setScreen(null);
	}
}

package com.oleo.cpmscripts.gui;

import java.lang.reflect.Field;

import org.lwjgl.glfw.GLFW;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.MultiLineEditBox;
import net.minecraft.client.gui.components.MultilineTextField;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;

import com.oleo.cpmscripts.ScriptEngine;

/** Редактор скрипта: многострочное поле в панели, Ctrl+S — сохранить, статус-строка. */
public class ScriptEditScreen extends Screen {
	private final Screen parent;
	private final String fileName;
	private MultiLineEditBox editor;
	private MultilineTextField textField; // внутреннее поле редактора (рефлексия) — для вставки с \n
	private int lines = 1, chars = 0;
	private long savedFlash; // время последнего сохранения для подсказки

	public ScriptEditScreen(Screen parent, String fileName) {
		super(Component.literal("Edit: " + fileName));
		this.parent = parent;
		this.fileName = fileName;
	}

	@Override
	protected void init() {
		int x = this.width / 2 - (this.width - 60) / 2;
		editor = MultiLineEditBox.builder()
				.setX(x + 6).setY(40)
				.setPlaceholder(Component.literal("-- lua script"))
				.setShowBackground(false)
				.build(this.font, this.width - 72, this.height - 120, Component.literal(fileName));
		editor.setValue(ScriptEngine.readScript(fileName));
		editor.setValueListener(v -> {
			chars = v.length();
			int n = 1;
			for (int i = 0; i < v.length(); i++) if (v.charAt(i) == '\n') n++;
			lines = n;
		});
		addRenderableWidget(editor);
		// достаём внутренний MultilineTextField — у него insertText не вырезает переводы строк
		try {
			Field f = MultiLineEditBox.class.getDeclaredField("textField");
			f.setAccessible(true);
			textField = (MultilineTextField) f.get(editor);
		} catch (Throwable ignored) {}
		// посчитать начальные значения
		String v = editor.getValue();
		chars = v.length();
		lines = 1;
		for (int i = 0; i < v.length(); i++) if (v.charAt(i) == '\n') lines++;

		int by = this.height - 58;
		int cx = this.width / 2;
		addRenderableWidget(new FlatButton(cx - 112, by, 100, 18, Component.literal("Save (Ctrl+S)"), b -> save(),
			0xFF23332E, 0xFF2E453D, GuiStyle.ON));
		addRenderableWidget(new FlatButton(cx + 12, by, 100, 18, Component.literal("Cancel"), b ->
			Minecraft.getInstance().setScreen(parent)));
	}

	private void save() {
		ScriptEngine.saveScript(fileName, editor.getValue());
		savedFlash = System.currentTimeMillis();
	}

	@Override
	public boolean keyPressed(KeyEvent event) {
		boolean ctrl = (event.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0;
		if (event.key() == GLFW.GLFW_KEY_S && ctrl) {
			save();
			return true;
		}
		// Ctrl+V: ванильная вставка вырезает переводы строк — вставляем сами, как есть
		if (event.key() == GLFW.GLFW_KEY_V && ctrl && textField != null && editor.isFocused()) {
			String clip = Minecraft.getInstance().keyboardHandler.getClipboard();
			if (clip != null && !clip.isEmpty()) {
				// табы шрифт MC рисует квадратами — заменяем на 2 пробела; переносы сохраняем
				textField.insertText(clip.replace("\r\n", "\n").replace('\r', '\n').replace("\t", "  "));
				return true;
			}
		}
		return super.keyPressed(event);
	}

	@Override
	public void render(GuiGraphics gg, int mouseX, int mouseY, float partialTick) {
		GuiStyle.background(gg, this.width, this.height);
		GuiStyle.header(gg, this.font, this.width, "CPM Scripts", "edit: " + fileName);
		int x = this.width / 2 - (this.width - 60) / 2;
		GuiStyle.panel(gg, x, 34, this.width - 60, this.height - 108);
		super.render(gg, mouseX, mouseY, partialTick);
		// статус-строка
		String status = lines + " строк, " + chars + " симв.";
		if (System.currentTimeMillis() - savedFlash < 1500) status += "   сохранено";
		gg.drawString(this.font, status, x + 8, this.height - 74, GuiStyle.MUTED);
	}

	@Override
	public void onClose() {
		Minecraft.getInstance().setScreen(parent);
	}
}

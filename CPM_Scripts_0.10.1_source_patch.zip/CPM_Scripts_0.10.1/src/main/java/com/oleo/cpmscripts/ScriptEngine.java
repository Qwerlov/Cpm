package com.oleo.cpmscripts;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import org.luaj.vm2.Globals;
import org.luaj.vm2.LuaError;
import org.luaj.vm2.LuaTable;
import org.luaj.vm2.LuaValue;
import org.luaj.vm2.Varargs;
import org.luaj.vm2.lib.OneArgFunction;
import org.luaj.vm2.lib.TwoArgFunction;
import org.luaj.vm2.lib.VarArgFunction;
import org.luaj.vm2.lib.jse.JsePlatform;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import com.oleo.cpmscripts.nodes.GraphCompiler;
import com.oleo.cpmscripts.nodes.NodeGraph;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Loads every *.lua file from config/cpmscripts and calls its global
 * function tick(dt) once per client tick.
 *
 * Globals available to scripts:
 *   player  - table with live player data (refreshed every tick, see fillPlayerData)
 *   cpm.set(name, value) - set CPM value layer, value 0..255
 *   cpm.get(name)        - current layer value or -1
 *   log(msg)             - print to the game chat
 */
public final class ScriptEngine {
	private static Path scriptsDir;
	private static final List<Script> scripts = new ArrayList<>();
	private static final java.util.Set<String> disabled = new java.util.HashSet<>();
	private static final java.util.Map<String, String> loadErrors = new java.util.HashMap<>();
	private static long generation = 0;
	private static volatile boolean enabled = true;

	// последнее сообщение в чате (ловится ClientReceiveMessageEvents.GAME)
	private static volatile String chatLast;
	private static volatile boolean chatFresh;

	// реальный удар по существу/блоку (AttackEntity/AttackBlock callback), тиков осталось
	private static volatile int attackEntityHitTicks;
	private static volatile int attackBlockHitTicks;

	// последнее взаимодействие ПКМ с блоком (UseBlockCallback)
	private static volatile String blockUseLast;
	private static volatile boolean blockUseFresh;

	private static final LuaTable playerTable = new LuaTable();
	private static final LuaTable velLocal = new LuaTable();
	private static final LuaTable velWorld = new LuaTable();
	private static final LuaTable viewVec = new LuaTable();
	private static float prevBodyYaw = 0;
	private static boolean firstTick = true;

	private ScriptEngine() {}

	private static final class Script {
		final String name;
		final Globals globals;
		final LuaValue tickFn;
		boolean errored;

		Script(String name, Globals globals) {
			this.name = name;
			this.globals = globals;
			this.tickFn = globals.get("tick");
		}
	}

	public static void init() {
		scriptsDir = FabricLoader.getInstance().getConfigDir().resolve("cpmscripts");
		try {
			Files.createDirectories(scriptsDir);
			Files.createDirectories(scriptsDir.resolve("lib")); // папка для модулей require
			Path help = scriptsDir.resolve("ИНСТРУКЦИЯ.txt");
			if (!Files.exists(help)) {
				try (InputStream in = ScriptEngine.class.getResourceAsStream("/cpmscripts_help.txt")) {
					if (in != null) Files.copy(in, help);
				}
			}
			// встроенные библиотеки: единый архив cpmscripts_libs.zip (10 .lua в корне).
			// Копируем в lib только отсутствующие — повторный запуск безвреден.
			boolean zipOk = false;
			try (InputStream in = ScriptEngine.class.getResourceAsStream("/cpmscripts_libs.zip");
				 java.util.zip.ZipInputStream zin = in == null ? null : new java.util.zip.ZipInputStream(in)) {
				if (zin != null) {
					zipOk = true;
					java.util.zip.ZipEntry e;
					while ((e = zin.getNextEntry()) != null) {
						if (e.isDirectory() || !e.getName().endsWith(".lua")) continue;
						Path dst = scriptsDir.resolve("lib").resolve(e.getName());
						if (!Files.exists(dst)) Files.copy(zin, dst);
					}
				}
			}
			if (!zipOk) { // архива в jar нет — старый способ, по одному файлу (для совместимости)
				String[] bundled = { "util.lua", "spring.lua", "noise.lua", "cloth.lua",
						"vec.lua", "easing.lua", "waves.lua", "fsm.lua", "rope.lua", "collision.lua" };
				for (String lib : bundled) {
					Path dst = scriptsDir.resolve("lib").resolve(lib);
					if (!Files.exists(dst)) {
						try (InputStream in = ScriptEngine.class.getResourceAsStream("/cpmscripts_lib/" + lib)) {
							if (in != null) Files.copy(in, dst);
						}
					}
				}
			}
		} catch (IOException e) {
			CpmScriptsClient.LOGGER.error("[CPM Scripts] Failed to create scripts dir", e);
		}
		loadDisabled();
		reload();
	}

	private static void loadDisabled() {
		disabled.clear();
		Path f = scriptsDir.resolve("disabled.txt");
		try {
			if (Files.exists(f)) disabled.addAll(Files.readAllLines(f, StandardCharsets.UTF_8));
		} catch (IOException ignored) {}
	}

	private static void saveDisabled() {
		try {
			Files.write(scriptsDir.resolve("disabled.txt"), new ArrayList<>(disabled), StandardCharsets.UTF_8);
		} catch (IOException ignored) {}
	}

	private static String safeName(String name) {
		String n = new java.io.File(name).getName();
		return n.endsWith(".lua") ? n : n + ".lua";
	}

	public static Path getScriptsDir() { return scriptsDir; }

	/** [name, "1"/"0" enabled, errorOrEmpty]. Скрипты *.lua + графы нод nodes/*.json. */
	public static synchronized List<String[]> scriptInfo() {
		List<String[]> out = new ArrayList<>();
		try (DirectoryStream<Path> ds = Files.newDirectoryStream(scriptsDir, "*.lua")) {
			for (Path f : ds) {
				String n = f.getFileName().toString();
				out.add(new String[]{n, disabled.contains(n) ? "0" : "1", loadErrors.getOrDefault(n, "")});
			}
		} catch (IOException ignored) {}
		// графы нод: отображаются как "nodes/<имя>.json"
		try (DirectoryStream<Path> ds = Files.newDirectoryStream(scriptsDir.resolve("nodes"), "*.json")) {
			for (Path f : ds) {
				String fn = f.getFileName().toString();
				String scriptName = "nodes/" + fn;
				boolean off = disabled.contains(fn) || disabled.contains(scriptName);
				out.add(new String[]{scriptName, off ? "0" : "1", loadErrors.getOrDefault(scriptName, "")});
			}
		} catch (IOException ignored) {}
		out.sort(java.util.Comparator.comparing(a -> a[0]));
		return out;
	}

	/** Тип записи в списке: скрипт (.lua) или граф (.json). */
	public static boolean isGraphName(String name) {
		return name.endsWith(".json") || name.startsWith("nodes/");
	}

	public static void setScriptEnabled(String name, boolean en) {
		// графы нод: имя "nodes/x.json" — храним как есть, без safeName (.lua-суффикс)
		if (!name.startsWith("nodes/")) name = safeName(name);
		if (en) disabled.remove(name); else disabled.add(name);
		saveDisabled();
		reload();
	}

	public static String readScript(String name) {
		try {
			return Files.readString(scriptsDir.resolve(safeName(name)), StandardCharsets.UTF_8);
		} catch (IOException e) { return ""; }
	}

	public static void saveScript(String name, String content) {
		try {
			Files.writeString(scriptsDir.resolve(safeName(name)), content, StandardCharsets.UTF_8);
		} catch (IOException e) {
			CpmScriptsClient.chat("[CPM Scripts] Save failed: " + e.getMessage());
		}
		reload();
	}

	public static void deleteScript(String name) {
		try {
			if (name.startsWith("nodes/")) Files.deleteIfExists(scriptsDir.resolve(name));
			else Files.deleteIfExists(scriptsDir.resolve(safeName(name)));
		} catch (IOException ignored) {}
		reload();
	}

	/** Переименовать скрипт или граф ("nodes/x.json"). Возвращает null или текст ошибки. */
	public static String renameScript(String oldName, String newName) {
		if (newName == null) return "пустое имя";
		newName = newName.trim();
		if (newName.isEmpty()) return "пустое имя";
		boolean graph = oldName.startsWith("nodes/");
		if (graph) {
			if (!newName.endsWith(".json")) newName += ".json";
		} else {
			newName = safeName(newName);
			oldName = safeName(oldName);
		}
		// проверяем только само имя, без служебного префикса "nodes/" (а то в нём "/" и всегда ошибка)
		String bare = graph && newName.startsWith("nodes/") ? newName.substring("nodes/".length()) : newName;
		if (bare.isEmpty()) return "пустое имя";
		if (bare.contains("/") || bare.contains("\\") || bare.contains("..") || bare.contains(":"))
			return "недопустимые символы в имени";
		if (oldName.equals(newName)) return null;
		try {
				Path src = scriptsDir.resolve(oldName);
				Path dst = graph ? scriptsDir.resolve("nodes").resolve(bare) : scriptsDir.resolve(newName);
			if (Files.exists(dst)) return "такое имя уже занято";
			Files.move(src, dst);
			// переносим состояние enabled/disabled
			if (disabled.remove(oldName)) { disabled.add(newName); saveDisabled(); }
			if (!graph && disabled.remove(safeName(oldName))) { disabled.add(newName); saveDisabled(); }
			reload();
			return null;
		} catch (IOException e) {
			return e.getMessage();
		}
	}

	public static String addScriptFrom(Path src) {
		try {
			Path dst = scriptsDir.resolve(safeName(src.getFileName().toString()));
			Files.copy(src, dst, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
			reload();
			return null;
		} catch (IOException e) { return e.getMessage(); }
	}

	public static synchronized void reload() {
		scripts.clear();
		loadErrors.clear();
		generation++;
		int ok = 0;
		List<String> failed = new ArrayList<>();
		try (DirectoryStream<Path> ds = Files.newDirectoryStream(scriptsDir, "*.lua")) {
			for (Path f : ds) {
				String n = f.getFileName().toString();
				if (disabled.contains(n)) continue;
				try {
					String code = Files.readString(f, StandardCharsets.UTF_8);
					Globals g = makeGlobals();
					g.load(new StringReader(code), n).call();
					scripts.add(new Script(n, g));
					ok++;
				} catch (Throwable t) {
					loadErrors.put(n, errMsg(t));
					failed.add(n + ": " + errMsg(t));
				}
			}
		} catch (IOException e) {
			CpmScriptsClient.chat("[CPM Scripts] Reload failed: " + e.getMessage());
			return;
		}

		// --- графы нод: nodes/*.json компилируются в Lua и грузятся как скрипты ---
		int okGraphs = 0;
		Path nodesDir = scriptsDir.resolve("nodes");
		try (DirectoryStream<Path> ds = Files.newDirectoryStream(nodesDir, "*.json")) {
			for (Path f : ds) {
				String fileName = f.getFileName().toString();
				String scriptName = "nodes/" + fileName; // отображаемое имя в списке
				if (disabled.contains(fileName) || disabled.contains(scriptName)) continue;
				try {
					NodeGraph graph = NodeGraph.load(f);
					String lua = GraphCompiler.compile(graph);
					Globals g = makeGlobals();
					g.load(new StringReader(lua), scriptName).call();
					scripts.add(new Script(scriptName, g));
					okGraphs++;
				} catch (Throwable t) {
					loadErrors.put(scriptName, errMsg(t));
					failed.add(fileName + ": " + errMsg(t));
				}
			}
		} catch (IOException ignored) {
			// папки nodes/ нет — и нормально
		}

			// CpmScriptsClient.chat("[CPM Scripts] Loaded " + ok + " script(s)" + (okGraphs > 0 ? " + " + okGraphs + " graph(s)" : "")
			// 			+ (failed.isEmpty() ? "" : ", failed: " + String.join("; ", failed)));
	}

	/** Run a one-off snippet (used by /cpmscripts run). Returns null on success, error text otherwise. */
	public static String runSnippet(String code) {
		try {
			Globals g = makeGlobals();
			fillPlayerData(Minecraft.getInstance());
			g.load(new StringReader(code), "snippet").call();
			return null;
		} catch (Throwable t) {
			return errMsg(t);
		}
	}

	/** require("lib.xxx") / require("xxx") из папки config/cpmscripts/lib. */
	private static void installLibSearcher(Globals g) {
		LuaValue pkg = g.get("package");
		if (!pkg.istable()) return;
		LuaValue searchers = pkg.get("searchers");
		if (searchers.isnil()) searchers = pkg.get("loaders"); // LuaJ 3.0.x
		if (!searchers.istable()) return;
		LuaValue loader = new OneArgFunction() {
			@Override
			public LuaValue call(LuaValue modname) {
				String rel = modname.tojstring().replace('.', '/') + ".lua";
				Path p = scriptsDir.resolve("lib").resolve(rel).normalize();
				if (!p.startsWith(scriptsDir.resolve("lib").normalize()) || !Files.exists(p)) {
					return LuaValue.valueOf("\n\tno lib file '" + rel + "' in cpmscripts/lib");
				}
				try {
					String code = Files.readString(p, StandardCharsets.UTF_8);
					return g.load(new StringReader(code), "@" + p.getFileName());
				} catch (IOException e) {
					return LuaValue.valueOf("\n\tcan't read " + rel + ": " + e.getMessage());
				}
			}
		};
		LuaTable tbl = searchers.checktable();
		// вставить вторым (после preload) один раз; метка защищает от дублей при reload
		if (tbl.get("cpmscripts_lib").isnil()) {
			for (int i = tbl.length() + 1; i > 2; i--) tbl.set(i, tbl.get(i - 1));
			tbl.set(2, loader);
			tbl.set("cpmscripts_lib", LuaValue.TRUE);
		}
	}

	private static Globals makeGlobals() {
		Globals g = JsePlatform.standardGlobals();
		installLibSearcher(g);
		// модули: require "lib.vec" ищет в config/cpmscripts/lib/vec.lua и т.п.
		LuaValue pkg = g.get("package");
		if (!pkg.isnil()) {
			// "?.lua" — шаблон пути для require; через Path.resolve нельзя:
			// '?' запрещён в путях Windows (InvalidPathException), хотя Linux его допускает
			String base = scriptsDir.toAbsolutePath().normalize().toString().replace('\\', '/');
			String path = base + "/?.lua;" + base + "/lib/?.lua";
			pkg.get("path"); // ensure field exists
			pkg.set("path", LuaValue.valueOf(path + ";" + pkg.get("path").optjstring("")));
		}
		g.set("player", playerTable);

		LuaTable cpm = new LuaTable();
		cpm.set("set", new TwoArgFunction() {
			@Override
			public LuaValue call(LuaValue name, LuaValue value) {
				boolean okRes = CpmBridge.setValue(name.checkjstring(), value.checkint());
				return LuaValue.valueOf(okRes);
			}
		});
		cpm.set("get", new OneArgFunction() {
			@Override
			public LuaValue call(LuaValue name) {
				return LuaValue.valueOf(CpmBridge.getValue(name.checkjstring()));
			}
		});
		cpm.set("play", new OneArgFunction() {
			@Override
			public LuaValue call(LuaValue name) {
				return LuaValue.valueOf(CpmBridge.play(name.checkjstring()));
			}
		});
		cpm.set("stop", new OneArgFunction() {
			@Override
			public LuaValue call(LuaValue name) {
				return LuaValue.valueOf(CpmBridge.stop(name.checkjstring()));
			}
		});
		cpm.set("ready", new VarArgFunction() {
			@Override
			public Varargs invoke(Varargs args) {
				return LuaValue.valueOf(CpmBridge.isReady());
			}
		});
		g.set("cpm", cpm);

		// world queries for collision-aware scripts (tail vs blocks)
		LuaTable world = new LuaTable();
		world.set("solid", new VarArgFunction() {
			@Override
			public Varargs invoke(Varargs args) {
				double x = args.arg(1).checkdouble();
				double y = args.arg(2).checkdouble();
				double z = args.arg(3).checkdouble();
				return LuaValue.valueOf(isSolid(x, y, z));
			}
		});
		world.set("block", new VarArgFunction() {
			@Override
			public Varargs invoke(Varargs args) {
				double x = args.arg(1).checkdouble();
				double y = args.arg(2).checkdouble();
				double z = args.arg(3).checkdouble();
				Minecraft mc = Minecraft.getInstance();
				if (mc.level == null) return LuaValue.NIL;
				BlockPos pos = BlockPos.containing(x, y, z);
				BlockState st = mc.level.getBlockState(pos);
				LuaTable t = new LuaTable();
				t.set("id", LuaValue.valueOf(String.valueOf(BuiltInRegistries.BLOCK.getKey(st.getBlock()))));
				t.set("solid", LuaValue.valueOf(!st.isAir() && st.isSolidRender()));
				t.set("air", LuaValue.valueOf(st.isAir()));
				t.set("liquid", LuaValue.valueOf(!st.getFluidState().isEmpty()));
				return t;
			}
		});
		// exact collision shape of a block: list of boxes in block-local coords (0..1)
		world.set("shape", new VarArgFunction() {
			@Override
			public Varargs invoke(Varargs args) {
				double x = args.arg(1).checkdouble();
				double y = args.arg(2).checkdouble();
				double z = args.arg(3).checkdouble();
				LuaTable arr = new LuaTable();
				Minecraft mc = Minecraft.getInstance();
				if (mc.level == null) return arr;
				BlockPos pos = BlockPos.containing(x, y, z);
				BlockState st = mc.level.getBlockState(pos);
				VoxelShape vs = st.getCollisionShape(mc.level, pos);
				int i = 1;
				for (AABB b : vs.toAabbs()) {
					LuaTable t = new LuaTable();
					t.set("x1", LuaValue.valueOf(b.minX - pos.getX()));
					t.set("y1", LuaValue.valueOf(b.minY - pos.getY()));
					t.set("z1", LuaValue.valueOf(b.minZ - pos.getZ()));
					t.set("x2", LuaValue.valueOf(b.maxX - pos.getX()));
					t.set("y2", LuaValue.valueOf(b.maxY - pos.getY()));
					t.set("z2", LuaValue.valueOf(b.maxZ - pos.getZ()));
					arr.set(i++, t);
				}
				return arr;
			}
		});
		// raycast vs block colliders: world.raycast(x1,y1,z1, x2,y2,z2) -> {hit,x,y,z,side,id}
		world.set("raycast", new VarArgFunction() {
			@Override
			public Varargs invoke(Varargs args) {
				LuaTable t = new LuaTable();
				Minecraft mc = Minecraft.getInstance();
				if (mc.level == null || mc.player == null) {
					t.set("hit", LuaValue.FALSE);
					return t;
				}
				Vec3 a = new Vec3(args.arg(1).checkdouble(), args.arg(2).checkdouble(), args.arg(3).checkdouble());
				Vec3 b = new Vec3(args.arg(4).checkdouble(), args.arg(5).checkdouble(), args.arg(6).checkdouble());
				BlockHitResult hit = mc.level.clip(new ClipContext(a, b,
						ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, mc.player));
				boolean isHit = hit.getType() != BlockHitResult.Type.MISS;
				t.set("hit", LuaValue.valueOf(isHit));
				Vec3 loc = hit.getLocation();
				t.set("x", LuaValue.valueOf(loc.x));
				t.set("y", LuaValue.valueOf(loc.y));
				t.set("z", LuaValue.valueOf(loc.z));
				if (isHit) {
					t.set("side", LuaValue.valueOf(hit.getDirection().getName()));
					BlockState st = mc.level.getBlockState(hit.getBlockPos());
					t.set("id", LuaValue.valueOf(String.valueOf(BuiltInRegistries.BLOCK.getKey(st.getBlock()))));
				}
				return t;
			}
		});
		// nearby entities: world.entities(radius) -> array of {id,name,x,y,z,dist,player}
		world.set("entities", new VarArgFunction() {
			@Override
			public Varargs invoke(Varargs args) {
				double r = args.arg(1).checkdouble();
				LuaTable arr = new LuaTable();
				Minecraft mc = Minecraft.getInstance();
				if (mc.level == null || mc.player == null) return arr;
				int i = 1;
				for (Entity e : mc.level.entitiesForRendering()) {
					if (e == mc.player) continue;
					double d = e.distanceTo(mc.player);
					if (d > r) continue;
					LuaTable t = new LuaTable();
					t.set("id", LuaValue.valueOf(String.valueOf(BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()))));
					t.set("name", LuaValue.valueOf(e.getName().getString()));
					t.set("x", LuaValue.valueOf(e.getX()));
					t.set("y", LuaValue.valueOf(e.getY()));
					t.set("z", LuaValue.valueOf(e.getZ()));
					t.set("dist", LuaValue.valueOf(d));
					t.set("player", LuaValue.valueOf(e instanceof Player));
					arr.set(i++, t);
					if (i > 64) break;
				}
				return arr;
			}
		});
		g.set("world", world);

		// keys.down("g") / keys.pressed("space") — любая клавиша по имени GLFW
		// (g, space, left.shift, f3 ...). pressed = фронт нажатия с прошлого тика.
		LuaTable keys = new LuaTable();
		final java.util.Map<String, Boolean> keyPrev = new java.util.HashMap<>(); // состояние на прошлый тик (на скрипт)
		keys.set("down", new OneArgFunction() {
			@Override
			public LuaValue call(LuaValue n) {
				return LuaValue.valueOf(keyDownByName(n.checkjstring()));
			}
		});
		keys.set("pressed", new OneArgFunction() {
			@Override
			public LuaValue call(LuaValue n) {
				String k = normKeyName(n.checkjstring());
				boolean down = keyDownByName(k);
				boolean prev = keyPrev.getOrDefault(k, false);
				keyPrev.put(k, down);
				return LuaValue.valueOf(down && !prev);
			}
		});
		g.set("keys", keys);

		g.set("log", new OneArgFunction() {
			@Override
			public LuaValue call(LuaValue v) {
				CpmScriptsClient.chat(v.tojstring());
				return LuaValue.NIL;
			}
		});
		g.set("sendLocalChat", new OneArgFunction() { // сообщение только в свой чат (не уходит на сервер)
			@Override
			public LuaValue call(LuaValue v) {
				Minecraft mc = Minecraft.getInstance();
				if (mc.gui != null) mc.gui.getChat().addMessage(net.minecraft.network.chat.Component.literal(v.tojstring()));
				return LuaValue.NIL;
			}
		});
		g.set("sendChat", new OneArgFunction() { // настоящее сообщение на сервер
			@Override
			public LuaValue call(LuaValue v) {
				Minecraft mc = Minecraft.getInstance();
				if (mc.player != null && mc.getConnection() != null)
					mc.getConnection().sendChat(v.tojstring());
				return LuaValue.NIL;
			}
		});
		g.set("hasEffect", new OneArgFunction() {
			@Override
			public LuaValue call(LuaValue v) { return LuaValue.valueOf(effect(v) != null); }
		});
		g.set("effectAmp", new OneArgFunction() {
			@Override
			public LuaValue call(LuaValue v) {
				MobEffectInstance e = effect(v);
				return LuaValue.valueOf(e == null ? 0 : e.getAmplifier());
			}
		});
		g.set("countEntities", new VarArgFunction() { // (type|"", radius, name|"") -> сущностей рядом
			@Override
			public Varargs invoke(Varargs args) {
				Minecraft mc = Minecraft.getInstance();
				if (mc.level == null || mc.player == null) return LuaValue.ZERO;
				double r = Math.max(1, Math.min(64, args.optdouble(2, 8)));
				String type = args.optjstring(1, "").trim().toLowerCase(java.util.Locale.ROOT);
				String name = args.optjstring(3, "").trim().toLowerCase(java.util.Locale.ROOT);
				AABB box = mc.player.getBoundingBox().inflate(r);
				int count = 0;
				for (var ent : mc.level.getEntities(mc.player, box)) {
					if (!type.isEmpty() && !type.equals(String.valueOf(
							net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE.getKey(ent.getType()))))
						continue;
					if (!name.isEmpty() && !ent.getName().getString().toLowerCase(java.util.Locale.ROOT).contains(name))
						continue;
					count++;
				}
				return LuaValue.valueOf(count);
			}
		});
		return g;
	}

	public static boolean isEnabled() {
		return enabled;
	}

	public static void setEnabled(boolean v) {
		enabled = v;
	}

	public static synchronized void tick(Minecraft mc) {
		if (!enabled || scripts.isEmpty()) return;
		fillPlayerData(mc);
		for (Script s : scripts) {
			if (s.errored || !s.tickFn.isfunction()) continue;
			try {
				s.tickFn.call(LuaValue.valueOf(0.05)); // dt = 1/20 s
			} catch (Throwable t) {
				s.errored = true;
				CpmScriptsClient.chat("[CPM Scripts] " + s.name + " stopped: " + errMsg(t));
			}
		}
		chatFresh = false; // "новое сообщение" горит один тик
		blockUseFresh = false;
		if (attackEntityHitTicks > 0) attackEntityHitTicks--;
		
		if (attackBlockHitTicks > 0) attackBlockHitTicks--;
	}

	/** Вызывается из ClientReceiveMessageEvents.GAME. overlay=true — actionbar, пропускаем. */
	public static void onChatMessage(net.minecraft.network.chat.Component message, boolean overlay) {
		if (overlay) return;
		chatLast = message.getString();
		chatFresh = true;
	}

	public static void onAttackEntityLanded() {
		attackEntityHitTicks = 2;
	}

	public static void onAttackBlockLanded() {
		attackBlockHitTicks = 2;
	}

	/** ПКМ по блоку (сундук, дверь, рычаг...); id вида "minecraft:chest". */
	public static void onUseBlock(net.minecraft.world.level.block.state.BlockState state) {
		blockUseLast = String.valueOf(BuiltInRegistries.BLOCK.getKey(state.getBlock()));
		blockUseFresh = true;
	}

	private static String normKeyName(String name) {
		String k = name.trim().toLowerCase(java.util.Locale.ROOT);
		if (k.startsWith("key.keyboard.")) k = k.substring("key.keyboard.".length());
		return k;
	}

	private static boolean keyDownByName(String name) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.getWindow() == null) return false;
		String k = normKeyName(name);
		if (k.isEmpty()) return false;
		try {
			com.mojang.blaze3d.platform.InputConstants.Key key =
					com.mojang.blaze3d.platform.InputConstants.getKey("key.keyboard." + k);
			return com.mojang.blaze3d.platform.InputConstants.isKeyDown(mc.getWindow(), key.getValue());
		} catch (Throwable t) {
			return false;
		}
	}

	/** Найти активный эффект по id ("minecraft:speed"); без namespace — с minecraft:. */
	private static MobEffectInstance effect(LuaValue idV) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null) return null;
		String id = idV.tojstring().trim().toLowerCase(java.util.Locale.ROOT);
		if (id.isEmpty()) return null;
		if (!id.contains(":")) id = "minecraft:" + id;
		for (MobEffectInstance e : mc.player.getActiveEffects()) {
			if (id.equals(String.valueOf(BuiltInRegistries.MOB_EFFECT.getKey(e.getEffect().value())))) return e;
		}
		return null;
	}

	private static boolean isSolid(double x, double y, double z) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.level == null) return false;
		BlockPos pos = BlockPos.containing(x, y, z);
		BlockState st = mc.level.getBlockState(pos);
		return !st.isAir() && st.isSolidRender();
	}

	private static String errMsg(Throwable t) {
		if (t instanceof LuaError && t.getCause() != null) return t.getCause().toString();
		String m = t.getMessage();
		return m != null ? m : t.toString();
	}

	private static void fillPlayerData(Minecraft mc) {
		LocalPlayer p = mc.player;
		if (p == null) return;

		float yaw = p.yBodyRot;
		float delta = firstTick ? 0 : ((yaw - prevBodyYaw + 540f) % 360f) - 180f;
		prevBodyYaw = yaw;
		firstTick = false;

		Vec3 v = p.getDeltaMovement();
		double rad = Math.toRadians(yaw);
		double sin = Math.sin(rad), cos = Math.cos(rad);
		// local axes: x+ = right of body, z+ = forward (facing direction)
		double lx = -v.x * cos - v.z * sin;
		double lz = -v.x * sin + v.z * cos;

		velLocal.set("x", LuaValue.valueOf(lx));
		velLocal.set("y", LuaValue.valueOf(v.y));
		velLocal.set("z", LuaValue.valueOf(lz));
		velWorld.set("x", LuaValue.valueOf(v.x));
		velWorld.set("y", LuaValue.valueOf(v.y));
		velWorld.set("z", LuaValue.valueOf(v.z));

		playerTable.set("vel", velLocal);
		playerTable.set("velWorld", velWorld);
		playerTable.set("x", LuaValue.valueOf(p.getX()));
		playerTable.set("y", LuaValue.valueOf(p.getY()));
		playerTable.set("z", LuaValue.valueOf(p.getZ()));
		playerTable.set("yaw", LuaValue.valueOf(yaw));
		playerTable.set("yawDelta", LuaValue.valueOf(delta));
		playerTable.set("onGround", LuaValue.valueOf(p.onGround()));
		playerTable.set("inWater", LuaValue.valueOf(p.isInWater()));
		playerTable.set("sprinting", LuaValue.valueOf(p.isSprinting()));
		playerTable.set("sneaking", LuaValue.valueOf(p.isShiftKeyDown()));
		playerTable.set("fallFlying", LuaValue.valueOf(p.isFallFlying()));
		playerTable.set("swimming", LuaValue.valueOf(p.isSwimming()));
		playerTable.set("crawling", LuaValue.valueOf(p.isVisuallyCrawling())); // ползанье: позы CRAWLING в 1.21.11 нет, метод - isVisuallyCrawling
		playerTable.set("pose", LuaValue.valueOf(p.getPose().name()));
		playerTable.set("time", LuaValue.valueOf(p.level().getGameTime()));

		playerTable.set("mainHand", itemTable(p.getMainHandItem()));
		playerTable.set("offHand", itemTable(p.getOffhandItem()));

		// head / view
		playerTable.set("headYaw", LuaValue.valueOf(p.yHeadRot));
		playerTable.set("pitch", LuaValue.valueOf(p.getXRot()));
		Vec3 view = p.getViewVector(1.0f);
		viewVec.set("x", LuaValue.valueOf(view.x));
		viewVec.set("y", LuaValue.valueOf(view.y));
		viewVec.set("z", LuaValue.valueOf(view.z));
		playerTable.set("view", viewVec);
		playerTable.set("walkPos", LuaValue.valueOf(p.walkAnimation.position()));
		playerTable.set("walkSpeed", LuaValue.valueOf(p.walkAnimation.speed()));
			playerTable.set("walking", LuaValue.valueOf(p.onGround() && p.walkAnimation.speed() > 0.01 && !p.isSprinting()));
			playerTable.set("running", LuaValue.valueOf(p.onGround() && p.isSprinting()));
			playerTable.set("pushup", LuaValue.valueOf(false));

		// combat / item use
		playerTable.set("swinging", LuaValue.valueOf(p.swinging));
		playerTable.set("swingTime", LuaValue.valueOf(p.swingTime));
		playerTable.set("using", LuaValue.valueOf(p.isUsingItem()));
		playerTable.set("useItem", itemTable(p.getUseItem()));
		// кнопка "использовать" (ПКМ) зажата — срабатывает для ЛЮБОГО предмета,
		// даже если у предмета нет use-действия (тогда isUsingItem() = false)
		playerTable.set("useKey", LuaValue.valueOf(mc.options.keyUse.isDown()));
		playerTable.set("attackKey", LuaValue.valueOf(mc.options.keyAttack.isDown()));

		// реальный удар попал (по существу или блоку), горит 2 тика
		playerTable.set("attackEntityHit", LuaValue.valueOf(attackEntityHitTicks > 0));
		playerTable.set("attackBlockHit", LuaValue.valueOf(attackBlockHitTicks > 0));

		// взаимодействие ПКМ с блоком
		playerTable.set("blockUse", blockUseLast == null ? LuaValue.NIL : LuaValue.valueOf(blockUseLast));
		playerTable.set("blockUseNew", LuaValue.valueOf(blockUseFresh));
		playerTable.set("useTicks", LuaValue.valueOf(p.getUseItemRemainingTicks()));

		// vitals
		playerTable.set("health", LuaValue.valueOf(p.getHealth()));
		playerTable.set("maxHealth", LuaValue.valueOf(p.getMaxHealth()));
		playerTable.set("absorption", LuaValue.valueOf(p.getAbsorptionAmount()));
		playerTable.set("food", LuaValue.valueOf(p.getFoodData().getFoodLevel()));
		playerTable.set("saturation", LuaValue.valueOf(p.getFoodData().getSaturationLevel()));
		playerTable.set("air", LuaValue.valueOf(p.getAirSupply()));
		playerTable.set("maxAir", LuaValue.valueOf(p.getMaxAirSupply()));
		playerTable.set("fallDistance", LuaValue.valueOf(p.fallDistance));
		playerTable.set("onFire", LuaValue.valueOf(p.isOnFire()));

		// time / weather / riding
		playerTable.set("dayTime", LuaValue.valueOf(p.level().getDayTime()));
		playerTable.set("raining", LuaValue.valueOf(p.level().isRaining()));
		playerTable.set("thundering", LuaValue.valueOf(p.level().isThundering()));
		playerTable.set("riding", LuaValue.valueOf(p.isPassenger()));
		Entity veh = p.getVehicle();
		playerTable.set("vehicle", LuaValue.valueOf(veh == null ? ""
				: String.valueOf(BuiltInRegistries.ENTITY_TYPE.getKey(veh.getType()))));

		LuaTable effects = new LuaTable();
		int i = 1;
		for (MobEffectInstance eff : p.getActiveEffects()) {
			LuaTable e = new LuaTable();
			e.set("id", LuaValue.valueOf(String.valueOf(BuiltInRegistries.MOB_EFFECT.getKey(eff.getEffect().value()))));
			e.set("amp", LuaValue.valueOf(eff.getAmplifier()));
			e.set("duration", LuaValue.valueOf(eff.getDuration()));
			effects.set(i++, e);
		}
		playerTable.set("effects", effects);

		// броня по слотам
		LuaTable armor = new LuaTable();
		armor.set("head", itemTable(p.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.HEAD)));
		armor.set("chest", itemTable(p.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.CHEST)));
		armor.set("legs", itemTable(p.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.LEGS)));
		armor.set("feet", itemTable(p.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.FEET)));
		playerTable.set("armor", armor);

		// чат: текст последнего сообщения + флаг "появилось в этом тике"
		playerTable.set("chatLast", chatLast == null ? LuaValue.NIL : LuaValue.valueOf(chatLast));
		playerTable.set("chatNew", LuaValue.valueOf(chatFresh));
	}

	private static LuaTable itemTable(ItemStack stack) {
		LuaTable t = new LuaTable();
		if (stack == null || stack.isEmpty()) {
			t.set("id", LuaValue.valueOf("minecraft:air"));
			t.set("name", LuaValue.valueOf(""));
			t.set("count", LuaValue.valueOf(0));
		} else {
			t.set("id", LuaValue.valueOf(String.valueOf(BuiltInRegistries.ITEM.getKey(stack.getItem()))));
			t.set("name", LuaValue.valueOf(stack.getHoverName().getString()));
			t.set("count", LuaValue.valueOf(stack.getCount()));
		}
		return t;
	}
}

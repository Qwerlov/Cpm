package com.oleo.cpmscripts.gui;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import com.oleo.cpmscripts.ScriptEngine;
import com.oleo.cpmscripts.nodes.GraphCompiler;
import com.oleo.cpmscripts.nodes.NodeGraph;
import com.oleo.cpmscripts.nodes.NodeGraphs;
import com.oleo.cpmscripts.nodes.NodeType;
import com.oleo.cpmscripts.nodes.NodeTypes;
import com.oleo.cpmscripts.nodes.NodeGraph.GNode;
import com.oleo.cpmscripts.nodes.NodeGraph.GWire;
import com.oleo.cpmscripts.nodes.NodeType.PType;

/**
 * Редактор графов нод: канвас с панорамой/зумом, ноды с портами, провода (как в Blockbench).
 * ПКМ по пустому месту — меню добавления ноды. Таскание за шапку — перенос.
 * Таскание от порта-выхода — новый провод (вход принимает один провод).
 * ЛКМ по проводу — выбор, Del — удалить. ПКМ по проводу — удалить сразу.
 * Колесо — зум, таскание пустого места — панорама.
 */
public class NodeCanvasScreen extends Screen {
	private static final int NODE_W = 150;
	private static final int HEADER_H = 14;
	private static final int ROW_H = 12;
	private static final int PORT_R = 3;
	private static final int BOOL_C = 0xFF7BD88F;
	private static final int NUM_C = 0xFFE8C170;
	private static final int STR_C = 0xFF9C8FE8;

	private static int portColor(PType type) {
		return switch (type) {
			case BOOL -> BOOL_C;
			case NUMBER -> NUM_C;
			default -> STR_C;
		};
	}

	// палитры: провода из одного порта получают разные цвета (по порядковому номеру)
	private static final int[] BOOL_PAL = {0xFF7BD88F, 0xFF4FD8C8, 0xFFB8D84F, 0xFFD8A04F, 0xFFD84FB0, 0xFF4F8FD8};
	private static final int[] NUM_PAL  = {0xFFE8C170, 0xFFE8865A, 0xFFEDE14F, 0xFFB8E14F, 0xFF5AE18E, 0xFF5AB8E1};
	private static final int[] STR_PAL  = {0xFF9C8FE8, 0xFFD88FE8, 0xFF8FB4E8, 0xFFE88FB4, 0xFFB48FE8, 0xFF8FE8D8};

	/** Цвет провода: i-й провод из одного порта = i-й цвет палитры своего типа. */
	private int wireColor(GNode from, String port, int wireIdx) {
		NodeType t = NodeTypes.byId(from.type);
		NodeType.Port p = t == null ? null : t.outputById(port);
		int[] pal = p == null ? BOOL_PAL : switch (p.type) {
			case BOOL -> BOOL_PAL;
			case NUMBER -> NUM_PAL;
			default -> STR_PAL;
		};
		return pal[wireIdx % pal.length];
	}

	private final Screen parent;
	private NodeGraph graph;
	private String status = "";
	private long statusUntil;

	private float panX = 40, panY = 40, zoom = 1f;
	private String dragNode;
	private double grabDX, grabDY;
	private boolean panning;
	private double lastMX, lastMY;
	private String[] connectFrom;      // {nodeId, portId} — тянем провод
	private boolean connectFromInput;  // тянули с входа (отпускаем на выходе)
	private String selectedNode;
	private final java.util.Set<String> multiSel = new java.util.LinkedHashSet<>(); // Ctrl+ЛКМ выделение
	private int groupCounter = 1;
	private int selectedWire = -1;     // индекс в graph.wires
	private double ctxX, ctxY;         // экранные координаты меню
	private double ctxWorldX, ctxWorldY; // мировая позиция, в которой пользователь вызвал меню
	private String ctxCategory;        // null = список категорий

	// --- отмена (Ctrl+Z): стек снапшотов графа ---
	private boolean dirty; // есть несохранённые изменения
	private final java.util.Deque<String> undoStack = new java.util.ArrayDeque<>();
	private String connectSnapshot;    // снапшот на момент хвата порта
	private String dragSnapshot;       // снапшот на момент начала переноса ноды
	private boolean dragMoved;

	public NodeCanvasScreen(Screen parent, String graphName) {
		super(Component.literal("Граф: " + graphName));
		this.parent = parent;
		try {
			this.graph = NodeGraphs.load(graphName);
		} catch (Throwable t) {
			this.graph = new NodeGraph();
			this.graph.name = graphName.replaceFirst("\\.json$", "");
			status("Не удалось открыть " + graphName + ": " + t.getMessage(), true);
		}
	}

	private void status(String msg, boolean isErr) {
		status = (isErr ? "§c" : "§a") + msg;
		statusUntil = System.currentTimeMillis() + 8000;
	}

	@Override
	protected void init() {
		addRenderableWidget(new FlatButton(6, this.height - 24, 70, 18,
				Component.literal("Назад"), b -> tryClose()));
		addRenderableWidget(new FlatButton(82, this.height - 24, 70, 18,
				Component.literal("Сохранить"), b -> save()));
		addRenderableWidget(new FlatButton(158, this.height - 24, 80, 18,
				Component.literal("Проверить"), b -> validate()));
		addRenderableWidget(new FlatButton(244, this.height - 24, 110, 18,
				Component.literal("Lua-код"), b -> showLua()));
		addRenderableWidget(new FlatButton(360, this.height - 24, 80, 18,
				Component.literal("В группу"), b -> groupSelected()));
		addRenderableWidget(new FlatButton(446, this.height - 24, 100, 18,
				Component.literal("Разгруппировать"), b -> ungroupSelected()));
	}

	private void save() {
		try {
			NodeGraphs.save(graph);
				dirty = false;
			ScriptEngine.reload();
			String err = errorOf(graph.name);
			if (err == null) status("Сохранено: " + graph.name + ".json", false);
			else status("Сохранено, но граф не работает: " + err, true);
		} catch (Throwable t) {
			status("Ошибка сохранения: " + t.getMessage(), true);
		}
	}

	private String errorOf(String name) {
		for (String[] info : ScriptEngine.scriptInfo()) {
			if (info[0].equals("nodes/" + name + ".json")) return info[2].isEmpty() ? null : info[2];
		}
		return null;
	}

	private void validate() {
		try {
			GraphCompiler.compile(graph);
			status("Граф корректен (" + graph.nodes.size() + " нод, " + graph.wires.size() + " проводов)", false);
		} catch (Throwable t) {
			status("Ошибка: " + t.getMessage(), true);
		}
	}

	private void showLua() {
		String lua;
		try {
			lua = GraphCompiler.compile(graph);
		} catch (Throwable t) {
			status("Не скомпилировался: " + t.getMessage(), true);
			return;
		}
		Minecraft.getInstance().setScreen(new TextViewScreen(this, "Сгенерированный Lua — " + graph.name, lua));
	}

	@Override
	public boolean isPauseScreen() { return false; }

	// ================= координаты =================
	private double toWorldX(double sx) { return (sx - panX) / zoom; }
	private double toWorldY(double sy) { return (sy - panY) / zoom; }

	/** Высота ноды в мировых пикселях. */
	private int nodeH(GNode n) {
		NodeType t = NodeTypes.byId(n.type);
		int rows = t == null ? 1 : Math.max(t.inputs.size(), t.outputs.size());
		return HEADER_H + rows * ROW_H + (t == null ? 0 : t.params.size()) * ROW_H + 6;
	}

	private double[] portPos(GNode n, String portId, boolean input) {
		NodeType t = NodeTypes.byId(n.type);
		double x = input ? n.x : n.x + NODE_W;
		double y = n.y + HEADER_H + ROW_H / 2.0;
		if (t != null) {
			List<NodeType.Port> ports = input ? t.inputs : t.outputs;
			for (int i = 0; i < ports.size(); i++) {
				if (ports.get(i).id.equals(portId)) {
					y = n.y + HEADER_H + i * ROW_H + ROW_H / 2.0;
					break;
				}
			}
		}
		return new double[]{x, y};
	}

	// ================= ввод =================
	@Override
	public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent evt, boolean doubleClick) {
		double sx = evt.x(), sy = evt.y();
		int btn = evt.button();
		// меню добавления ноды
		if (ctxCategory != null || isCtxOpen()) {
			if (handleCtxClick(sx, sy)) return true;
			closeCtx();
			return true; // клик вне меню закрывает его
		}
		if (sy < 28 || sy > this.height - 28) return super.mouseClicked(evt, doubleClick);

		double wx = toWorldX(sx), wy = toWorldY(sy);

		if (btn == 1) { // ПКМ
			GNode n = nodeAt(wx, wy);
			if (n != null) {
				pushUndo();
				graph.removeNode(n.id);
				if (n.id.equals(selectedNode)) selectedNode = null;
				multiSel.remove(n.id);
				return true;
			}
			int wi = wireAt(sx, sy);
			if (wi >= 0) { pushUndo(); graph.wires.remove(wi); if (selectedWire == wi) selectedWire = -1; return true; }
			openCtx(sx, sy);
			return true;
		}

		if (btn == 0) {
			// сначала порт: с порта с проводом тоже можно тянуть новый провод
			String[] port = portAt(wx, wy, false);
			if (port == null) port = portAt(wx, wy, true);
			if (port != null) {
				connectSnapshot = snapshot();
				connectFrom = port;
				connectFromInput = portAt(wx, wy, false) == null;
				return true;
			}
			int wi = wireAt(sx, sy);
			if (wi >= 0) { selectedWire = wi; selectedNode = null; return true; }
			GNode n = nodeAt(wx, wy);
			// Ctrl+ЛКМ по ноде — мульти-выделение для групп
			if (n != null && (evt.modifiers() & org.lwjgl.glfw.GLFW.GLFW_MOD_CONTROL) != 0) {
				if (!multiSel.remove(n.id)) multiSel.add(n.id);
				selectedNode = n.id;
				selectedWire = -1;
				return true;
			}
			if (n != null) {
				// клик по параметру?
				NodeType t = NodeTypes.byId(n.type);
				if (t != null) {
					int rows = Math.max(t.inputs.size(), t.outputs.size());
					for (int i = 0; i < t.params.size(); i++) {
						double py = n.y + HEADER_H + rows * ROW_H + i * ROW_H;
						if (wy >= py && wy < py + ROW_H) {
							openParamEditor(n, t.params.get(i));
							return true;
						}
					}
				}
				selectedNode = n.id;
				selectedWire = -1;
				if (!multiSel.contains(n.id)) multiSel.clear();
				dragNode = n.id;
				dragSnapshot = snapshot();
				dragMoved = false;
				grabDX = wx - n.x; grabDY = wy - n.y;
				// таскаемая нода переносится в конец списка — рисуется и хит-тестится сверху
				graph.nodes.remove(n);
				graph.nodes.add(n);
				return true;
			}
			panning = true;
			lastMX = sx; lastMY = sy;
			selectedNode = null;
			selectedWire = -1;
			multiSel.clear();
			return true;
		}
		return super.mouseClicked(evt, doubleClick);
	}

	@Override
	public boolean mouseReleased(net.minecraft.client.input.MouseButtonEvent evt) {
		double sx = evt.x(), sy = evt.y();
		int btn = evt.button();
		dragNode = null;
		panning = false;
		if (dragSnapshot != null && dragMoved) { undoStack.push(dragSnapshot); trimUndo(); dirty = true; }
		dragSnapshot = null;
		dragMoved = false;
		if (connectFrom != null && btn == 0) {
			double wx = toWorldX(sx), wy = toWorldY(sy);
			// с какой стороны тянули — с той ищем порт под курсором
			String[] target = portAt(wx, wy, !connectFromInput);
			if (target != null && !target[0].equals(connectFrom[0])) {
				String fromNode = connectFrom[0], fromPort = connectFrom[1];
				String toNode = target[0], toPort = target[1];
				if (connectFromInput) { // тянули от входа — концы меняются местами
					toNode = connectFrom[0]; toPort = connectFrom[1];
					fromNode = target[0]; fromPort = target[1];
				}
				NodeType ft = NodeTypes.byId(graph.nodeById(fromNode).type);
				NodeType tt = NodeTypes.byId(graph.nodeById(toNode).type);
				if (ft != null && tt != null
						&& ft.outputById(fromPort).type == tt.inputById(toPort).type) {
					// проводов может быть несколько: и с входа, и с выхода
					if (connectSnapshot != null) { undoStack.push(connectSnapshot); trimUndo(); connectSnapshot = null; dirty = true; }
					GWire w = new GWire();
					w.fromNode = fromNode; w.fromPort = fromPort;
					w.toNode = toNode; w.toPort = toPort;
					graph.wires.add(w);
				}
			}
			connectFrom = null;
			return true;
		}
		return super.mouseReleased(evt);
	}

	@Override
	public boolean mouseDragged(net.minecraft.client.input.MouseButtonEvent evt, double dx, double dy) {
		double sx = evt.x(), sy = evt.y();
		if (dragNode != null) {
			GNode n = graph.nodeById(dragNode);
			if (n != null) {
				// Используем реальные дельты drag-события: координаты MouseButtonEvent
				// в некоторых версиях Minecraft остаются координатами нажатия.
				int nx = n.x + (int) Math.round(dx / zoom);
				int ny = n.y + (int) Math.round(dy / zoom);
				int mdx = nx - n.x, mdy = ny - n.y;
				// ноды той же группы двигаются вместе
				if (n.group != null && !n.group.isEmpty() && (mdx != 0 || mdy != 0)) {
					for (GNode o : graph.nodes) {
						if (o != n && n.group.equals(o.group)) { o.x += mdx; o.y += mdy; }
					}
				}
				n.x = nx;
				n.y = ny;
				dragMoved = true;
			}
			return true;
		}
		if (panning) {
			panX += dx;
			panY += dy;
			return true;
		}
		return super.mouseDragged(evt, dx, dy);
	}

	@Override
	public boolean mouseScrolled(double sx, double sy, double scrollX, double scrollY) {
		float old = zoom;
		zoom = (float) Math.max(0.4, Math.min(2.5, zoom * (scrollY > 0 ? 1.15 : 1 / 1.15)));
		panX = (float) (sx - (sx - panX) * (zoom / old));
		panY = (float) (sy - (sy - panY) * (zoom / old));
		return true;
	}

	@Override
	public boolean keyPressed(net.minecraft.client.input.KeyEvent evt) {
		int key = evt.key();
		if (key == 259 || key == 261) { // Backspace/Delete
			if (selectedWire >= 0 && selectedWire < graph.wires.size()) {
				pushUndo();
				graph.wires.remove(selectedWire);
				selectedWire = -1;
				return true;
			}
			if (selectedNode != null) {
				pushUndo();
				graph.removeNode(selectedNode);
				multiSel.remove(selectedNode);
				selectedNode = null;
				return true;
			}
		}
		if (key == 90 && (evt.modifiers() & org.lwjgl.glfw.GLFW.GLFW_MOD_CONTROL) != 0) { // Ctrl+Z
			undo();
			return true;
		}
		if (key == 256) { // Esc
			if (isCtxOpen()) { closeCtx(); return true; }
			tryClose();
			return true;
		}
		return super.keyPressed(evt);
	}

	/** Выход: если есть несохранённые изменения — диалог Сохранить/Не сохранять/Отмена. */
	private void tryClose() {
		if (!dirty) { onClose(); return; }
		Minecraft.getInstance().setScreen(new SaveConfirmScreen(this,
				() -> { save(); Minecraft.getInstance().setScreen(parent); },
				() -> Minecraft.getInstance().setScreen(parent)));
	}

	@Override
	public void onClose() {
		Minecraft.getInstance().setScreen(parent);
	}

	// ================= отмена =================
	private String snapshot() {
		return graph.toJson();
	}

	private void pushUndo() {
		dirty = true;
		undoStack.push(snapshot());
		trimUndo();
	}

	private void trimUndo() {
		while (undoStack.size() > 50) undoStack.removeLast();
	}

	private void undo() {
		String snap = undoStack.poll();
		if (snap == null) { status("Отменять нечего", true); return; }
		try {
			graph = NodeGraph.fromJson(snap);
			selectedNode = null;
			multiSel.clear();
			selectedWire = -1;
			dragNode = null;
			connectFrom = null;
			status("Отменено (осталось шагов: " + undoStack.size() + ")", false);
		} catch (Throwable t) {
			status("Не удалось отменить: " + t.getMessage(), true);
		}
	}

	// ================= группы =================
	/** Ноды, попадающие под действие кнопок групп: выделенная + мульти-выделение. */
	private java.util.List<GNode> targets() {
		java.util.List<GNode> out = new ArrayList<>();
		for (String id : multiSel) {
			GNode n = graph.nodeById(id);
			if (n != null) out.add(n);
		}
		if (selectedNode != null) {
			GNode n = graph.nodeById(selectedNode);
			if (n != null && !out.contains(n)) out.add(n);
		}
		return out;
	}

	private void groupSelected() {
		java.util.List<GNode> t = targets();
		if (t.isEmpty()) { status("Сначала выдели ноды: клик по ноде, Ctrl+клик — ещё одна", true); return; }
		pushUndo();
		String g = "g" + (groupCounter++);
		for (GNode n : t) n.group = g;
		status("В группе " + g + ": " + t.size() + " нод(ы). Тяни любую — двигаются вместе", false);
	}

	private void ungroupSelected() {
		java.util.List<GNode> t = targets();
		if (t.isEmpty()) { status("Нет выделенных нод", true); return; }
		pushUndo();
		for (GNode n : t) n.group = null;
		status("Группа расформирована (" + t.size() + " нод)", false);
	}

	private static int groupColor(String g) {
		int h = g == null ? 0 : g.hashCode();
		int r = 90 + (h & 0x3F);          // 90..153 — неяркие цвета
		int gr = 90 + ((h >> 6) & 0x3F);
		int b = 90 + ((h >> 12) & 0x3F);
		return 0xFF000000 | (r << 16) | (gr << 8) | b;
	}

	// ================= хит-тесты =================
	private GNode nodeAt(double wx, double wy) {
		for (int i = graph.nodes.size() - 1; i >= 0; i--) {
			GNode n = graph.nodes.get(i);
			if (wx >= n.x && wx <= n.x + NODE_W && wy >= n.y && wy <= n.y + nodeH(n)) return n;
		}
		return null;
	}

	/** Найти порт в точке. input=true — входы, false — выходы. */
	private String[] portAt(double wx, double wy, boolean input) {
		double r = PORT_R + 3 / zoom;
		for (GNode n : graph.nodes) {
			NodeType t = NodeTypes.byId(n.type);
			if (t == null) continue;
			List<NodeType.Port> ports = input ? t.inputs : t.outputs;
			for (NodeType.Port p : ports) {
				double[] pos = portPos(n, p.id, input);
				if (Math.abs(wx - pos[0]) <= r && Math.abs(wy - pos[1]) <= r)
					return new String[]{n.id, p.id};
			}
		}
		return null;
	}

	private int wireAt(double sx, double sy) {
		for (int i = 0; i < graph.wires.size(); i++) {
			GWire w = graph.wires.get(i);
			GNode fn = graph.nodeById(w.fromNode), tn = graph.nodeById(w.toNode);
			if (fn == null || tn == null) continue;
			double[] a = portPos(fn, w.fromPort, false);
			double[] b = portPos(tn, w.toPort, true);
			double[] s0 = {a[0] * zoom + panX, a[1] * zoom + panY};
			double[] s1 = {b[0] * zoom + panX, b[1] * zoom + panY};
			for (double tt = 0; tt <= 1.0; tt += 0.05) {
				double[] p = bezier(s0, s1, tt);
				double d = Math.hypot(p[0] - sx, p[1] - sy);
				if (d < 6) return i;
			}
		}
		return -1;
	}

	private static double[] bezier(double[] a, double[] b, double t) {
		double cx = Math.max(40, Math.abs(b[0] - a[0]) * 0.5);
		double x0 = a[0] + cx, x1 = b[0] - cx;
		double mt = 1 - t;
		double x = mt*mt*mt*a[0] + 3*mt*mt*t*x0 + 3*mt*t*t*x1 + t*t*t*b[0];
		double y = mt*mt*mt*a[1] + 3*mt*mt*t*a[1] + 3*mt*t*t*b[1] + t*t*t*b[1];
		return new double[]{x, y};
	}

	// ================= контекстное меню =================
	private boolean ctxOpen;

	private boolean isCtxOpen() { return ctxOpen; }

	private void openCtx(double sx, double sy) {
		ctxOpen = true;
		ctxCategory = null;
		ctxWorldX = toWorldX(sx);
		ctxWorldY = toWorldY(sy);
		// высота меню = максимум элементов (категории или ноды категории) + заголовок
		int maxEntries = NodeTypes.CATEGORIES.size();
		for (String c : NodeTypes.CATEGORIES) maxEntries = Math.max(maxEntries, NodeTypes.byCategory(c).size());
		int h = maxEntries * 14 + 22, w = 170;
		ctxX = Math.max(0, Math.min(sx, this.width - w));           // не уходит за бока
		if (sy + h > this.height - 44) {
				ctxY = Math.max(32, sy - h);
			} else {
				ctxY = Math.max(32, sy);
			}    // в пределах видимой области канваса
	}

	private void closeCtx() {
		ctxOpen = false;
		ctxCategory = null;
	}

	private List<String> ctxEntries() {
		List<String> e = new ArrayList<>();
		if (ctxCategory == null) e.addAll(NodeTypes.CATEGORIES);
		else for (NodeType t : NodeTypes.byCategory(ctxCategory)) e.add(t.title);
		return e;
	}

	private boolean handleCtxClick(double sx, double sy) {
		List<String> entries = ctxEntries();
		int x = (int) ctxX, y = (int) ctxY;
		int w = 170; // как в renderCtx
		int idx = ((int) sy - (y + 16)) / 14; // строки начинаются ниже заголовка меню
		if (sx < x || sx > x + w || idx < 0 || idx >= entries.size()) return false;
		String picked = entries.get(idx);
		if (ctxCategory == null) {
			ctxCategory = picked;
		} else {
			for (NodeType t : NodeTypes.byCategory(ctxCategory)) {
				if (t.title.equals(picked)) {
					pushUndo();
					GNode n = new GNode();
					n.id = graph.nextId();
					n.type = t.id;
					n.x = (int) Math.round(ctxWorldX - NODE_W / 2.0);
					n.y = Math.max(30, (int) Math.round(ctxWorldY - HEADER_H)); // размещаем возле исходного клика, не возле меню
					for (NodeType.Param p : t.params) {
						String v = !p.defText.isEmpty() ? p.defText
								: p.kind == NodeType.PKind.NUMBER ? String.valueOf(p.def)
								: !p.options.isEmpty() ? p.options.get(0) : "";
						n.params.put(p.id, v);
					}
					graph.nodes.add(n);
					break;
				}
			}
			closeCtx();
		}
		return true;
	}

	// ================= редакторы параметров =================
	private void openParamEditor(GNode n, NodeType.Param p) {
		String cur = n.params.getOrDefault(p.id, "");
		Minecraft mc = Minecraft.getInstance();
		switch (p.kind) {
			case DROPDOWN -> mc.setScreen(NodeParamScreen.dropdown(this, p.label, p.options, p.optLabels, cur,
					v -> { pushUndo(); n.params.put(p.id, v); }));
			case NUMBER -> mc.setScreen(NodeParamScreen.number(this, p.label,
					parseOr(cur, p.def), v -> { pushUndo(); n.params.put(p.id, v); }));
			case TEXT -> mc.setScreen(NodeParamScreen.text(this, p.label, cur, v -> { pushUndo(); n.params.put(p.id, v); }));
			case ANIM -> mc.setScreen(NodeParamScreen.anims(this, cur, v -> { pushUndo(); n.params.put(p.id, v); }));
			case LAYER -> mc.setScreen(NodeParamScreen.layers(this, cur, v -> { pushUndo(); n.params.put(p.id, v); }));
			case ITEM -> mc.setScreen(NodeParamScreen.items(this, cur, v -> { pushUndo(); n.params.put(p.id, v); }));
				case EFFECT -> mc.setScreen(NodeParamScreen.effects(this, cur, v -> { pushUndo(); n.params.put(p.id, v); }));
				case ENTITY -> mc.setScreen(NodeParamScreen.entities(this, cur, v -> { pushUndo(); n.params.put(p.id, v); }));
				case BLOCK -> mc.setScreen(NodeParamScreen.blocks(this, cur, v -> { pushUndo(); n.params.put(p.id, v); }));
		}
	}

	private static double parseOr(String s, double def) {
		try { return Double.parseDouble(s); } catch (Throwable t) { return def; }
	}

	// ================= рендер =================
	@Override
	public void render(GuiGraphics gg, int mouseX, int mouseY, float partialTick) {
		GuiStyle.background(gg, this.width, this.height);

		// канвас и сетка рисуются строго между рамками: шапка (0..32) и низ (height - 44)
		gg.enableScissor(0, 32, this.width, this.height - 44);
		renderGrid(gg);
		renderWires(gg, mouseX, mouseY);
		for (GNode n : graph.nodes) renderNode(gg, n, mouseX, mouseY);
		if (ctxOpen) renderCtx(gg);
		gg.disableScissor();

		// шапка рисуется поверх всего, рамка чистая
		GuiStyle.header(gg, this.font, this.width, "Граф: " + graph.name,
				graph.nodes.size() + " нод · " + graph.wires.size() + " проводов");

		super.render(gg, mouseX, mouseY, partialTick); // кнопки нижней панели

		gg.drawString(this.font, "ПКМ — меню нод · Ctrl+клик — выделить · В группу — двигать вместе · Del · Ctrl+Z · колесо — зум", 6, this.height - 38, GuiStyle.MUTED);
		if (System.currentTimeMillis() < statusUntil) {
			gg.drawString(this.font, status, 160, this.height - 38, GuiStyle.TEXT);
		}
	}

	private void renderGrid(GuiGraphics gg) {
		int step = (int) (32 * zoom);
		if (step < 8) step = 8;
		int offX = (int) (panX % step), offY = (int) (panY % step);
		// линии вместо точек: ~2 сотни fill вместо десятков тысяч
		for (int x = offX; x < this.width; x += step) gg.fill(x, 32, x + 1, this.height - 44, 0xFF23252E);
		for (int y = Math.max(32, offY); y < this.height - 44; y += step) gg.fill(0, y, this.width, y + 1, 0xFF23252E);
	}

	private void renderWires(GuiGraphics gg, int mouseX, int mouseY) {
		for (int i = 0; i < graph.wires.size(); i++) {
			GWire w = graph.wires.get(i);
			GNode fn = graph.nodeById(w.fromNode), tn = graph.nodeById(w.toNode);
			if (fn == null || tn == null) continue;
			double[] a = portPos(fn, w.fromPort, false);
			double[] b = portPos(tn, w.toPort, true);
			int color = wireColor(fn, w.fromPort, wireSlot(i));
			if (i == selectedWire) color = 0xFFFFFFFF;
			drawBezier(gg, a, b, color);
		}
		// тянущийся провод (от выхода или от входа)
		if (connectFrom != null) {
			GNode fn = graph.nodeById(connectFrom[0]);
			if (fn != null) {
				double[] a = portPos(fn, connectFrom[1], connectFromInput);
				double[] b = {toWorldX(mouseX), toWorldY(mouseY)};
				int color;
				NodeType t0 = NodeTypes.byId(fn.type);
				NodeType.Port p0 = t0 == null ? null
						: (connectFromInput ? t0.inputById(connectFrom[1]) : t0.outputById(connectFrom[1]));
				int[] pal = p0 == null ? BOOL_PAL : switch (p0.type) {
					case BOOL -> BOOL_PAL;
					case NUMBER -> NUM_PAL;
					default -> STR_PAL;
				};
				// следующий слот = сколько проводов уже висит на этом порту
				int slot = 0;
				for (GWire w0 : graph.wires) {
					if (w0.fromNode.equals(connectFrom[0]) && w0.fromPort.equals(connectFrom[1])) slot++;
				}
				color = pal[slot % pal.length];
				drawBezier(gg, a, b, color);
			}
		}
	}

	/** Порядковый номер провода среди проводов из того же выходного порта. */
	private int wireSlot(int wireIdx) {
		GWire w = graph.wires.get(wireIdx);
		int slot = 0;
		for (int i = 0; i < wireIdx; i++) {
			GWire o = graph.wires.get(i);
			if (o.fromNode.equals(w.fromNode) && o.fromPort.equals(w.fromPort)) slot++;
		}
		return slot;
	}

	private void drawBezier(GuiGraphics gg, double[] aWorld, double[] bWorld, int color) {
		double[] a = {aWorld[0] * zoom + panX, aWorld[1] * zoom + panY};
		double[] b = {bWorld[0] * zoom + panX, bWorld[1] * zoom + panY};
		double[] prev = a;
		for (double t = 0.1; t <= 1.001; t += 0.1) {
			double[] p = bezier(a, b, Math.min(t, 1.0));
			drawLine(gg, prev[0], prev[1], p[0], p[1], color);
			prev = p;
		}
	}

	private static void drawLine(GuiGraphics gg, double x0, double y0, double x1, double y1, int color) {
		// линия точками (fill по сегментам)
		double steps = Math.max(1, Math.hypot(x1 - x0, y1 - y0) / 2);
		for (int i = 0; i <= steps; i++) {
			double t = i / steps;
			int x = (int) Math.round(x0 + (x1 - x0) * t);
			int y = (int) Math.round(y0 + (y1 - y0) * t);
			gg.fill(x, y, x + 2, y + 2, color);
		}
	}

	private void renderNode(GuiGraphics gg, GNode n, int mouseX, int mouseY) {
		NodeType t = NodeTypes.byId(n.type);
		if (t == null) return;
		int h = nodeH(n);
		boolean sel = n.id.equals(selectedNode);

		gg.pose().pushMatrix();
		gg.pose().translate(n.x * zoom + panX, n.y * zoom + panY);
		gg.pose().scale(zoom, zoom);

		GuiStyle.panel(gg, 0, 0, NODE_W, h);
		if (sel) {
			gg.fill(-1, -1, NODE_W + 1, 0, GuiStyle.ACCENT);
			gg.fill(-1, h, NODE_W + 1, h + 1, GuiStyle.ACCENT);
			gg.fill(-1, 0, 0, h, GuiStyle.ACCENT);
			gg.fill(NODE_W, 0, NODE_W + 1, h, GuiStyle.ACCENT);
		} else if (n.group != null && !n.group.isEmpty() || multiSel.contains(n.id)) {
			// цветная рамка группы / мульти-выделения
			int c = multiSel.contains(n.id) ? GuiStyle.ACCENT : groupColor(n.group);
			gg.fill(-1, -1, NODE_W + 1, 0, c);
			gg.fill(-1, h, NODE_W + 1, h + 1, c);
			gg.fill(-1, 0, 0, h, c);
			gg.fill(NODE_W, 0, NODE_W + 1, h, c);
		}
		// шапка
		gg.fill(0, 0, NODE_W, HEADER_H, categoryColor(t.category));
		String title = t.title;
		if (this.font.width(title) > NODE_W - 8) title = this.font.plainSubstrByWidth(title, NODE_W - 14) + "…";
		gg.drawString(this.font, title, 4, 3, GuiStyle.TEXT);

		// порты и подписи
		int rows = Math.max(t.inputs.size(), t.outputs.size());
		for (int i = 0; i < t.inputs.size(); i++) {
			NodeType.Port p = t.inputs.get(i);
			int py = HEADER_H + i * ROW_H + ROW_H / 2;
			gg.fill(-PORT_R, py - PORT_R, PORT_R, py + PORT_R, portColor(p.type));
			gg.drawString(this.font, p.label, 7, py - 3, GuiStyle.MUTED);
		}
		for (int i = 0; i < t.outputs.size(); i++) {
			NodeType.Port p = t.outputs.get(i);
			int py = HEADER_H + i * ROW_H + ROW_H / 2;
			gg.fill(NODE_W - PORT_R, py - PORT_R, NODE_W + PORT_R, py + PORT_R, portColor(p.type));
			int lw = this.font.width(p.label);
			gg.drawString(this.font, p.label, NODE_W - 7 - lw, py - 3, GuiStyle.MUTED);
		}
		// параметры
		for (int i = 0; i < t.params.size(); i++) {
			NodeType.Param p = t.params.get(i);
			int py = HEADER_H + rows * ROW_H + i * ROW_H;
			String v = n.params.getOrDefault(p.id, "");
			String val = v.isEmpty() ? "—" : shortVal(p, v);
			// обрезаем подпись так, чтобы значение осталось видно
			String lab = p.label;
			while (!lab.isEmpty() && this.font.width(lab + ": " + val) > NODE_W - 10)
				lab = lab.substring(0, lab.length() - 1);
			String label = lab + ": " + val;
			gg.fill(4, py, NODE_W - 4, py + ROW_H - 1, GuiStyle.BTN);
			gg.drawString(this.font, label, 7, py + 2, GuiStyle.ACCENT);
		}

		gg.pose().popMatrix();
	}

	private String shortVal(NodeType.Param p, String v) {
		if (p.kind == NodeType.PKind.ITEM && v.startsWith("minecraft:")) return v.substring("minecraft:".length());
		if (p.kind == NodeType.PKind.NUMBER && v.endsWith(".0")) return v.substring(0, v.length() - 2);
		return v;
	}

	private static int categoryColor(String cat) {
		return switch (cat) {
			case "Входы" -> 0xFF24455C;
			case "Логика" -> 0xFF3C3358;
			case "Время" -> 0xFF4A3A2A;
			case "Константы" -> 0xFF2E4636;
			default -> 0xFF4C2E3A; // Действия
		};
	}

	private void renderCtx(GuiGraphics gg) {
		List<String> entries = ctxEntries();
		int x = (int) ctxX, y = (int) ctxY;
		int w = 170, h = entries.size() * 14 + 22;
		GuiStyle.panel(gg, x, y, w, h);
		gg.drawString(this.font, ctxCategory == null ? "Добавить ноду:" : ctxCategory, x + 6, y + 4, GuiStyle.ACCENT);
		for (int i = 0; i < entries.size(); i++) {
			int ry = y + 16 + i * 14;
			gg.drawString(this.font, entries.get(i), x + 10, ry, GuiStyle.TEXT);
		}
	}
}

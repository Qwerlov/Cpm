package com.oleo.cpmscripts;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mojang.brigadier.arguments.StringArgumentType;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;

import com.mojang.blaze3d.platform.InputConstants;

import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

public class CpmScriptsClient implements ClientModInitializer {
	public static final String MOD_ID = "cpmscripts";
	public static final Logger LOGGER = LoggerFactory.getLogger("CPM Scripts");

	// 6 generic keybinds for scripts (bound in Controls menu)
	public static final KeyMapping[] scriptKeys = new KeyMapping[6];
	public static final boolean[] keyDown = new boolean[6];
	public static final boolean[] keyPressed = new boolean[6];
	public static KeyMapping openGuiKey;

	@Override
	public void onInitializeClient() {
		// кнопка открытия GUI скриптов (по умолчанию K)
		openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
				"key.cpmscripts.gui",
				InputConstants.Type.KEYSYM, InputConstants.KEY_K, KeyMapping.Category.MISC));

		ScriptEngine.init();

		// ловим чат: ноды "Чат: сообщение" / "Проверка строки"
		ClientReceiveMessageEvents.GAME.register((message, overlay) ->
				ScriptEngine.onChatMessage(message, overlay));

		// реальные события Майна (не костыли по состоянию кнопок):
		// попадание ударом по существу/блоку и ПКМ по блоку
		net.fabricmc.fabric.api.event.player.AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
			if (world.isClientSide()) ScriptEngine.onAttackEntityLanded();
			return net.minecraft.world.InteractionResult.PASS;
		});
		net.fabricmc.fabric.api.event.player.AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
			if (world.isClientSide()) ScriptEngine.onAttackEntityLanded();
			return net.minecraft.world.InteractionResult.PASS;
		});
		net.fabricmc.fabric.api.event.player.UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
			if (world.isClientSide() && hitResult != null)
				ScriptEngine.onUseBlock(world.getBlockState(hitResult.getBlockPos()));
			return net.minecraft.world.InteractionResult.PASS;
		});

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openGuiKey.consumeClick()) {
				client.execute(() -> client.setScreen(
						client.screen instanceof com.oleo.cpmscripts.gui.ScriptListScreen ? null
								: new com.oleo.cpmscripts.gui.ScriptListScreen()));
			}
			if (client.player != null && !client.isPaused()) {
				ScriptEngine.tick(client);
			}
		});

		ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
			dispatcher.register(ClientCommandManager.literal("cpmscripts")
				.then(ClientCommandManager.literal("reload")
					.executes(ctx -> {
						ScriptEngine.reload();
						return 1;
					}))
				.then(ClientCommandManager.literal("toggle")
					.executes(ctx -> {
						ScriptEngine.setEnabled(!ScriptEngine.isEnabled());
						chat("[CPM Scripts] Scripts: " + (ScriptEngine.isEnabled() ? "ON" : "OFF"));
						return 1;
					}))
				.then(ClientCommandManager.literal("on")
					.executes(ctx -> {
						ScriptEngine.setEnabled(true);
						chat("[CPM Scripts] Scripts: ON");
						return 1;
					}))
				.then(ClientCommandManager.literal("off")
					.executes(ctx -> {
						ScriptEngine.setEnabled(false);
						chat("[CPM Scripts] Scripts: OFF");
						return 1;
					}))
				.then(ClientCommandManager.literal("run")
					.then(ClientCommandManager.argument("code", StringArgumentType.greedyString())
						.executes(ctx -> {
							String code = StringArgumentType.getString(ctx, "code");
							String err = ScriptEngine.runSnippet(code);
							chat(err == null ? "[CPM Scripts] OK" : "[CPM Scripts] Error: " + err);
							return 1;
						})))));
	}

	public static void chat(String msg) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.gui != null) {
			mc.gui.getChat().addMessage(Component.literal(msg));
		}
	}
}

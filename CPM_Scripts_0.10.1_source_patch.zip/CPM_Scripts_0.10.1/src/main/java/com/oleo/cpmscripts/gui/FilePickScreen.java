package com.oleo.cpmscripts.gui;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import net.fabricmc.loader.api.FabricLoader;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import com.oleo.cpmscripts.CpmScriptsClient;
import com.oleo.cpmscripts.ScriptEngine;

/** Внутриигровой выбор .lua файла — запасной вариант, если нативное окно недоступно. */
public class FilePickScreen extends Screen {
	private static final int ROWS = 12;
	private static final int ROW_H = 20;
	private static final int LIST_W = 320;

	private final Screen parent;
	private Path dir;
	private int page;
	private List<Path> entries = new ArrayList<>();

	public FilePickScreen(Screen parent) {
		super(Component.literal("Add script"));
		this.parent = parent;
		this.dir = FabricLoader.getInstance().getGameDir();
	}

	@Override
	protected void init() {
		loadDir();
		int x = this.width / 2 - LIST_W / 2;
		int y = 40;

		if (dir.getParent() != null) {
			addRenderableWidget(new FlatButton(x + 6, y, LIST_W - 12, 16, Component.literal("[..]"), b -> {
				dir = dir.getParent();
				page = 0;
				rebuildWidgets();
			}));
			y += ROW_H;
		}

		int start = page * ROWS;
		for (int i = 0; i < ROWS && start + i < entries.size(); i++) {
			Path p = entries.get(start + i);
			boolean isDir = Files.isDirectory(p);
			String label = isDir ? "[" + p.getFileName() + "]" : p.getFileName().toString();
			addRenderableWidget(new FlatButton(x + 6, y, LIST_W - 12, 16, Component.literal(label), b -> {
				if (isDir) {
					dir = p;
					page = 0;
					rebuildWidgets();
				} else {
					String err = ScriptEngine.addScriptFrom(p);
					if (err != null) CpmScriptsClient.chat("Ошибка копирования: " + err);
					Minecraft.getInstance().setScreen(parent);
				}
			}, isDir ? GuiStyle.BTN : 0xFF24303C, GuiStyle.BTN_HOVER, isDir ? GuiStyle.TEXT : GuiStyle.ACCENT));
			y += ROW_H;
		}

		int by = this.height - 58;
		if (page > 0) addRenderableWidget(new FlatButton(x + 6, by, 70, 18, Component.literal("< prev"), b -> { page--; rebuildWidgets(); }));
		if ((page + 1) * ROWS < entries.size())
			addRenderableWidget(new FlatButton(x + LIST_W - 76, by, 70, 18, Component.literal("next >"), b -> { page++; rebuildWidgets(); }));
		addRenderableWidget(new FlatButton(x + LIST_W / 2 - 40, by, 80, 18, Component.literal("Cancel"), b ->
			Minecraft.getInstance().setScreen(parent)));
	}

	private void loadDir() {
		entries.clear();
		try (var stream = Files.list(dir)) {
			stream.filter(p -> Files.isDirectory(p) || p.getFileName().toString().endsWith(".lua"))
					.sorted(Comparator.comparing((Path p) -> !Files.isDirectory(p))
							.thenComparing(p -> p.getFileName().toString().toLowerCase()))
					.forEach(entries::add);
		} catch (IOException e) {
			CpmScriptsClient.chat("Не читается папка: " + e.getMessage());
		}
	}

	@Override
	public void render(GuiGraphics gg, int mouseX, int mouseY, float partialTick) {
		GuiStyle.background(gg, this.width, this.height);
		GuiStyle.header(gg, this.font, this.width, "CPM Scripts", "add file");
		int x = this.width / 2 - LIST_W / 2;
		GuiStyle.panel(gg, x, 34, LIST_W, this.height - 100);
		String path = dir.toString();
		if (path.length() > 48) path = "..." + path.substring(path.length() - 45);
		gg.drawString(this.font, path, x + 8, this.height - 74, GuiStyle.MUTED);
		super.render(gg, mouseX, mouseY, partialTick);
	}

	@Override
	public void onClose() {
		Minecraft.getInstance().setScreen(parent);
	}
}

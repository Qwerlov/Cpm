package com.oleo.cpmscripts.nodes;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.oleo.cpmscripts.nodes.NodeGraph.GNode;
import com.oleo.cpmscripts.nodes.NodeGraph.GWire;
import com.oleo.cpmscripts.nodes.NodeType.PType;

/**
 * Компиляция графа нод в Lua-скрипт (dataflow).
 * Каждый тик: ноды вычисляются в топологическом порядке, провода = чтение локалов вышестоящих нод.
 * Состояние (фронты, таймеры, триггеры) живёт в таблице st, переживает между тиками.
 */
public final class GraphCompiler {

	public static final class CompileException extends Exception {
		public CompileException(String msg) { super(msg); }
	}

	private GraphCompiler() {}

	/** Провод, входящий в порт (должен быть максимум один — инпут-порт). */
	private static GWire wireInto(NodeGraph g, String nodeId, String port) {
		for (GWire w : g.wires) {
			if (w.toNode.equals(nodeId) && w.toPort.equals(port)) return w;
		}
		return null;
	}

	private static String luaStr(String s) {
		if (s == null) return "\"\"";
		StringBuilder sb = new StringBuilder("\"");
		for (char c : s.toCharArray()) {
			switch (c) {
				case '"': sb.append("\\\""); break;
				case '\\': sb.append("\\\\"); break;
				case '\n': sb.append("\\n"); break;
				case '\r': sb.append("\\r"); break;
				default: sb.append(c);
			}
		}
		return sb.append('"').toString();
	}

	/** Нормализация id предмета: trim + lowercase; без namespace добавляется minecraft:. */
	private static String normItem(String s) {
		if (s == null) return "minecraft:air";
		s = s.trim().toLowerCase(java.util.Locale.ROOT);
		if (s.isEmpty()) return "minecraft:air";
		if (!s.contains(":")) s = "minecraft:" + s;
		return s;
	}

	private static String num(double v) {
		if (v == Math.floor(v) && !Double.isInfinite(v)) return Long.toString((long) v);
		return Double.toString(v);
	}

	public static String compile(NodeGraph g) throws CompileException {
		// --- валидация ---
		for (GNode n : g.nodes) {
			if (NodeTypes.byId(n.type) == null)
				throw new CompileException("нод " + n.id + ": неизвестный тип '" + n.type + "'");
		}
		Map<String, NodeType> types = new HashMap<>();
		for (GNode n : g.nodes) types.put(n.id, NodeTypes.byId(n.type));
		for (GWire w : g.wires) {
			NodeType ft = types.get(w.fromNode), tt = types.get(w.toNode);
			if (ft == null || tt == null)
				throw new CompileException("провод ссылается на несуществующую ноду");
			NodeType.Port fp = ft.outputById(w.fromPort), tp = tt.inputById(w.toPort);
			if (fp == null || tp == null)
				throw new CompileException("провод " + w.fromNode + "." + w.fromPort + " -> "
						+ w.toNode + "." + w.toPort + ": нет такого порта");
			if (fp.type != tp.type)
				throw new CompileException("провод " + w.fromNode + "." + w.fromPort + " -> "
						+ w.toNode + "." + w.toPort + ": несовместимые типы");
		}

		// --- топологическая сортировка (Kahn) ---
		Map<String, Integer> indeg = new LinkedHashMap<>();
		for (GNode n : g.nodes) indeg.put(n.id, 0);
		Map<String, List<String>> downstream = new HashMap<>();
		for (GWire w : g.wires) {
			indeg.merge(w.toNode, 1, Integer::sum);
			downstream.computeIfAbsent(w.fromNode, k -> new ArrayList<>()).add(w.toNode);
		}
		Deque<String> queue = new ArrayDeque<>();
		for (Map.Entry<String, Integer> e : indeg.entrySet())
			if (e.getValue() == 0) queue.add(e.getKey());
		List<String> order = new ArrayList<>();
		while (!queue.isEmpty()) {
			String id = queue.poll();
			order.add(id);
			for (String dn : downstream.getOrDefault(id, List.of())) {
				int d = indeg.merge(dn, -1, Integer::sum);
				if (d == 0) queue.add(dn);
			}
		}
		if (order.size() < g.nodes.size())
			throw new CompileException("в графе есть цикл (замкнутые провода)");

		// --- генерация ---
		StringBuilder sb = new StringBuilder();
		sb.append("-- cpmscripts: граф \"").append(g.name).append("\" — сгенерировано из nodes/")
				.append(g.name).append(".json, правки сотрутся\n");
		sb.append("local st = {}\n\n");
		sb.append("function tick(dt)\n");

		for (String id : order) {
			GNode n = g.nodeById(id);
			NodeType t = types.get(id);
			emit(sb, g, n, t);
		}

		sb.append("end\n");
		return sb.toString();
	}

	private static String param(GNode n, NodeType t, String pid) {
		String v = n.params.get(pid);
		if (v == null || v.isEmpty()) {
			NodeType.Param p = t.paramById(pid);
			if (p != null) return p.defText.isEmpty() ? Double.toString(p.def) : p.defText;
		}
		return v == null ? "" : v;
	}

	private static double paramNum(GNode n, NodeType t, String pid) {
		String v = n.params.get(pid);
		if (v == null || v.isEmpty()) {
			NodeType.Param p = t.paramById(pid);
			return p == null ? 0 : p.def;
		}
		try {
			return Double.parseDouble(v);
		} catch (NumberFormatException e) {
			NodeType.Param p = t.paramById(pid);
			return p == null ? 0 : p.def;
		}
	}

	/** Выражение для входного порта: провод → локал апстрима, иначе дефолт. */
	private static String inExpr(NodeGraph g, Map<String, NodeType> types, GNode n, String port, String def) {
		GWire w = wireInto(g, n.id, port);
		if (w == null) return def;
		return "o_" + w.fromNode + "_" + w.fromPort;
	}

	private static void emit(StringBuilder sb, NodeGraph g, GNode n, NodeType t) throws CompileException {
		Map<String, NodeType> types = new HashMap<>();
		for (GNode x : g.nodes) types.put(x.id, NodeTypes.byId(x.type));
		String id = n.id;
		sb.append("  -- ").append(id).append(": ").append(t.title).append('\n');
		switch (t.id) {
			// ---------- ВХОДЫ ----------
			case "item_held": {
				String item = luaStr(normItem(param(n, t, "item")));
				String hand = param(n, t, "hand");
				String cond = switch (hand) {
					case "off" -> "(player.offHand.id == " + item + ")";
					case "any" -> "(player.mainHand.id == " + item + " or player.offHand.id == " + item + ")";
					default -> "(player.mainHand.id == " + item + ")";
				};
				sb.append("  local o_").append(id).append("_out = ").append(cond).append('\n');
				break;
			}
			case "item_use": {
				String item = luaStr(normItem(param(n, t, "item")));
				// два случая: предмет реально в use-действии (тетива, еда) ИЛИ
				// зажата ПКМ с этим предметом в любой руке (для предметов без use-действия)
				String cond = "(player.using and player.useItem.id == " + item + ")"
						+ " or (player.useKey and (player.mainHand.id == " + item
						+ " or player.offHand.id == " + item + "))";
				if ("press".equals(param(n, t, "mode"))) {
					sb.append("  local cur = ").append(cond).append('\n');
					sb.append("  local o_").append(id).append("_out = cur and not st.e").append(id)
							.append("; st.e").append(id).append(" = cur\n");
				} else {
					sb.append("  local o_").append(id).append("_out = ").append(cond).append('\n');
				}
				break;
			}
			case "chat_in": {
				sb.append("  local o_").append(id).append("_new = player.chatNew\n");
				sb.append("  local o_").append(id).append("_msg = player.chatLast\n");
				// первое число в тексте сообщения (целое или дробное), иначе nil
				sb.append("  local o_").append(id).append("_num = nil\n");
				sb.append("  if o_").append(id).append("_msg ~= nil then o_").append(id)
						.append("_num = tonumber(string.match(o_").append(id)
						.append("_msg, \"%-?%d+%.?%d*\")) end\n");
				break;
			}
			case "chat_match": {
				String m = inExpr(g, types, n, "msg", "player.chatLast");
				String f = inExpr(g, types, n, "find", luaStr(param(n, t, "text")));
				boolean full = "full".equals(param(n, t, "mode"));
				sb.append("  local m_").append(id).append(" = ").append(m).append('\n');
				sb.append("  local f_").append(id).append(" = ").append(f).append('\n');
				sb.append("  local o_").append(id).append("_out = m_").append(id).append(" ~= nil and f_")
						.append(id).append(" ~= nil and f_").append(id).append(" ~= \"\" and (");
				if (full) {
					sb.append("m_").append(id).append(" == f_").append(id);
				} else {
					sb.append("string.find(m_").append(id).append(", f_").append(id)
							.append(", 1, true) ~= nil");
				}
				sb.append(")\n");
				break;
			}
			case "equip": {
				String slot = param(n, t, "slot");
				String item = luaStr(normItem(param(n, t, "item")));
				sb.append("  local o_").append(id).append("_out = player.armor.").append(slot)
						.append(".id == ").append(item).append('\n');
				break;
			}
			case "effect": {
				String eff = luaStr(normItem(param(n, t, "effect")));
				sb.append("  local o_").append(id).append("_has = hasEffect(").append(eff).append(")\n");
				sb.append("  local o_").append(id).append("_amp = effectAmp(").append(eff).append(")\n");
				break;
			}
			case "entities": {
				String typeRaw = param(n, t, "type").trim().toLowerCase(java.util.Locale.ROOT);
				String type = luaStr(typeRaw.isEmpty() ? "" : normItem(typeRaw));
				String name = luaStr(param(n, t, "name").trim().toLowerCase(java.util.Locale.ROOT));
				String radius = num(paramNum(n, t, "radius"));
				sb.append("  local c_").append(id).append(" = countEntities(").append(type)
						.append(", ").append(radius).append(", ").append(name).append(")\n");
				sb.append("  local o_").append(id).append("_count = c_").append(id).append('\n');
				sb.append("  local o_").append(id).append("_has = c_").append(id).append(" > 0\n");
				break;
			}
			case "key": {
				String kn = luaStr(param(n, t, "n"));
				String fn = "down".equals(param(n, t, "mode")) ? "down" : "pressed";
				sb.append("  local o_").append(id).append("_out = keys.").append(fn)
						.append("(").append(kn).append(")\n");
				break;
			}
			case "mouse": {
				sb.append("  local ap_").append(id).append(" = player.attackKey\n");
				sb.append("  local o_").append(id).append("_attack = ap_").append(id).append('\n');
				sb.append("  local o_").append(id).append("_attackPress = ap_").append(id)
						.append(" and not st.m").append(id).append("a\n");
				sb.append("  local o_").append(id).append("_attackRelease = not ap_").append(id)
						.append(" and st.m").append(id).append("a\n");
				sb.append("  st.m").append(id).append("a = ap_").append(id).append('\n');
				sb.append("  local up_").append(id).append(" = player.useKey\n");
				sb.append("  local o_").append(id).append("_use = up_").append(id).append('\n');
				sb.append("  local o_").append(id).append("_usePress = up_").append(id)
						.append(" and not st.m").append(id).append("u\n");
				sb.append("  local o_").append(id).append("_useRelease = not up_").append(id)
						.append(" and st.m").append(id).append("u\n");
				sb.append("  st.m").append(id).append("u = up_").append(id).append('\n');
				break;
			}
			case "hit": {
				sb.append("  local cur = player.attackHit\n");
				sb.append("  local o_").append(id).append("_hit = cur\n");
				sb.append("  local o_").append(id).append("_press = cur and not st.h").append(id)
						.append("; st.h").append(id).append(" = cur\n");
				break;
			}
			case "block_use": {
				String blockRaw = param(n, t, "block").trim().toLowerCase(java.util.Locale.ROOT);
				String block = luaStr(blockRaw.isEmpty() ? "" : normItem(blockRaw));
				sb.append("  local o_").append(id).append("_new = player.blockUseNew and player.blockUse ~= nil\n");
				sb.append("  local o_").append(id).append("_id = player.blockUse\n");
				sb.append("  local o_").append(id).append("_match = player.blockUseNew and player.blockUse ~= nil and (")
						.append(block).append(" == \"\" or player.blockUse == ").append(block).append(")\n");
				break;
			}
			case "pose": {
				String s = param(n, t, "state");
				String cond = switch (s) {
					case "sneak" -> "player.sneaking";
					case "walking" -> "player.walking";
					case "sprint" -> "player.sprinting";
					case "swim" -> "player.swimming";
					case "crawl" -> "player.crawling";
					case "sleep" -> "(player.pose == \"SLEEPING\")";
					case "elytra" -> "player.fallFlying";
					case "ride" -> "player.riding";
					case "falling" -> "(not player.onGround and player.velWorld.y < -0.05)";
					case "onGround" -> "player.onGround";
					case "inWater" -> "player.inWater";
					case "onFire" -> "player.onFire";
					default -> "false";
				};
				sb.append("  local o_").append(id).append("_out = ").append(cond).append('\n');
				break;
			}
			case "vital": {
				String stat = param(n, t, "stat");
				String cmp = cmpLua(param(n, t, "cmp"));
				sb.append("  local o_").append(id).append("_out = (player.").append(stat)
						.append(" ").append(cmp).append(" ").append(num(paramNum(n, t, "value"))).append(")\n");
				break;
			}
			case "move": {
				sb.append("  local o_").append(id).append("_out = (math.sqrt(player.vel.x * player.vel.x")
						.append(" + player.vel.z * player.vel.z) >= ").append(num(paramNum(n, t, "speed"))).append(")\n");
				break;
			}

			// ---------- ЛОГИКА ----------
			case "and": case "or": case "xor": case "nor": case "nand": {
				String a = inExpr(g, types, n, "a", "false");
				String b = inExpr(g, types, n, "b", "false");
				String op = switch (t.id) {
					case "and" -> "(" + a + " and " + b + ")";
					case "or" -> "(" + a + " or " + b + ")";
					case "xor" -> "(" + a + " ~= " + b + ")";
					case "nor" -> "(not (" + a + " or " + b + "))";
					default -> "(not (" + a + " and " + b + "))";
				};
				sb.append("  local o_").append(id).append("_out = ").append(op).append('\n');
				break;
			}
			case "not": {
				String i = inExpr(g, types, n, "in", "false");
				sb.append("  local o_").append(id).append("_out = not ").append(i).append('\n');
				break;
			}
			case "edge": {
				String i = inExpr(g, types, n, "in", "false");
				sb.append("  local cur = ").append(i).append('\n');
				sb.append("  local o_").append(id).append("_out = cur and not st.e").append(id)
						.append("; st.e").append(id).append(" = cur\n");
				break;
			}
			case "toggle": {
				String i = inExpr(g, types, n, "in", "false");
				sb.append("  local cur = ").append(i).append('\n');
				sb.append("  if cur and not st.e").append(id).append(" then st.tg").append(id)
						.append(" = not st.tg").append(id).append(" end\n");
				sb.append("  st.e").append(id).append(" = cur\n");
				sb.append("  local o_").append(id).append("_out = st.tg").append(id).append(" == true\n");
				break;
			}
			case "latch": {
				String s = inExpr(g, types, n, "set", "false");
				String r = inExpr(g, types, n, "reset", "false");
				sb.append("  if ").append(s).append(" then st.la").append(id).append(" = true")
						.append(" elseif ").append(r).append(" then st.la").append(id).append(" = false end\n");
				sb.append("  local o_").append(id).append("_out = st.la").append(id).append(" == true\n");
				break;
			}

			// ---------- ВРЕМЯ ----------
			case "timer": {
				String i = inExpr(g, types, n, "in", "false");
				sb.append("  local cur = ").append(i).append('\n');
				sb.append("  if cur and not st.e").append(id).append(" then st.tm").append(id)
						.append(" = ").append(num(paramNum(n, t, "sec"))).append(" end\n");
				sb.append("  st.e").append(id).append(" = cur\n");
				sb.append("  local o_").append(id).append("_out = false\n");
				sb.append("  if st.tm").append(id).append(" then st.tm").append(id)
						.append(" = st.tm").append(id).append(" - dt\n");
				sb.append("    if st.tm").append(id).append(" > 0 then o_").append(id)
						.append("_out = true else st.tm").append(id).append(" = nil end\n");
				sb.append("  end\n");
				break;
			}
			case "delay": {
				String i = inExpr(g, types, n, "in", "false");
				sb.append("  local cur = ").append(i).append('\n');
				sb.append("  if cur and not st.e").append(id).append(" and not st.arm").append(id)
						.append(" then st.arm").append(id).append(" = true; st.tm").append(id)
						.append(" = ").append(num(paramNum(n, t, "sec"))).append(" end\n");
				sb.append("  if not cur then st.arm").append(id).append(" = nil end\n");
				sb.append("  st.e").append(id).append(" = cur\n");
				sb.append("  local o_").append(id).append("_out = false\n");
				sb.append("  if st.arm").append(id).append(" then st.tm").append(id)
						.append(" = st.tm").append(id).append(" - dt\n");
				sb.append("    if st.tm").append(id).append(" <= 0 then st.arm").append(id)
						.append(" = nil; if cur then o_").append(id).append("_out = true end end\n");
				sb.append("  end\n");
				break;
			}
			case "cooldown": {
				String i = inExpr(g, types, n, "in", "false");
				sb.append("  local cur = ").append(i).append('\n');
				sb.append("  local o_").append(id).append("_out = false\n");
				sb.append("  if cur and not st.e").append(id).append(" then\n");
				sb.append("    local now = player.time\n");
				sb.append("    if not st.cd").append(id).append(" or now - st.cd").append(id)
						.append(" >= ").append(num(paramNum(n, t, "sec") * 20)).append(" then\n");
				sb.append("      st.cd").append(id).append(" = now; o_").append(id).append("_out = true\n");
				sb.append("    end\n");
				sb.append("  end\n");
				sb.append("  st.e").append(id).append(" = cur\n");
				break;
			}
			case "cycle": {
				String i = inExpr(g, types, n, "in", "false");
				sb.append("  local o_").append(id).append("_out = false\n");
				sb.append("  if ").append(i).append(" then\n");
				sb.append("    st.cy").append(id).append(" = (st.cy").append(id).append(" or 0) + 1\n");
				sb.append("    if st.cy").append(id).append(" >= ").append(num(paramNum(n, t, "ticks")))
						.append(" then st.cy").append(id).append(" = 0; o_").append(id).append("_out = true end\n");
				sb.append("  else st.cy").append(id).append(" = 0\n");
				sb.append("  end\n");
				break;
			}

			// ---------- КОНСТАНТЫ ----------
			case "const_num": {
				sb.append("  local o_").append(id).append("_out = ")
						.append(num(paramNum(n, t, "value"))).append('\n');
				break;
			}
			case "compare": {
				String a = inExpr(g, types, n, "a", "0");
				String b = inExpr(g, types, n, "b", "0");
				sb.append("  local o_").append(id).append("_out = (").append(a).append(" ")
						.append(cmpLua(param(n, t, "cmp"))).append(" ").append(b).append(")\n");
				break;
			}

			// ---------- ДЕЙСТВИЯ ----------
			case "play": {
				String i = inExpr(g, types, n, "in", "false");
				String anim = luaStr(param(n, t, "anim"));
				if ("while".equals(param(n, t, "mode"))) {
					sb.append("  local cur = ").append(i).append('\n');
					sb.append("  if cur and not st.e").append(id).append(" then cpm.play(").append(anim).append(") end\n");
					sb.append("  if not cur and st.e").append(id).append(" then cpm.stop(").append(anim).append(") end\n");
					sb.append("  st.e").append(id).append(" = cur\n");
				} else {
					sb.append("  local cur = ").append(i).append('\n');
					sb.append("  if cur and not st.e").append(id).append(" then cpm.play(").append(anim).append(") end\n");
					sb.append("  st.e").append(id).append(" = cur\n");
				}
				break;
			}
			case "stop": {
				String i = inExpr(g, types, n, "in", "false");
				sb.append("  local cur = ").append(i).append('\n');
				sb.append("  if cur and not st.e").append(id).append(" then cpm.stop(")
						.append(luaStr(param(n, t, "anim"))).append(") end\n");
				sb.append("  st.e").append(id).append(" = cur\n");
				break;
			}
			case "set_layer": {
				String i = inExpr(g, types, n, "in", "false");
				String v = inExpr(g, types, n, "value", num(128));
				String layer = luaStr(param(n, t, "layer"));
				boolean once = "once".equals(param(n, t, "mode"));
				sb.append("  local cur = ").append(i).append('\n');
				if (once) {
					sb.append("  if cur and not st.e").append(id).append(" then cpm.set(")
							.append(layer).append(", math.floor(").append(v).append(" + 0.5)) end\n");
				} else {
					sb.append("  if cur then cpm.set(").append(layer).append(", math.floor(")
							.append(v).append(" + 0.5)) end\n");
				}
				if ("reset".equals(param(n, t, "release")) && !once) {
					sb.append("  if not cur and st.e").append(id).append(" then cpm.set(")
							.append(layer).append(", 128) end\n");
				}
				sb.append("  st.e").append(id).append(" = cur\n");
				break;
			}
			case "chat": {
				String i = inExpr(g, types, n, "in", "false");
				boolean server = "server".equals(param(n, t, "target"));
				sb.append("  local cur = ").append(i).append('\n');
				sb.append("  if cur and not st.e").append(id).append(" then ")
						.append(server ? "sendChat(" : "sendLocalChat(")
						.append(luaStr(param(n, t, "text"))).append(") end\n");
				sb.append("  st.e").append(id).append(" = cur\n");
				break;
			}

			default:
				throw new CompileException("нод " + id + ": тип '" + t.id + "' без генератора");
		}
	}

	private static String cmpLua(String cmp) {
		return switch (cmp) {
			case "<=" -> "<=";
			case "==" -> "==";
			case ">=" -> ">=";
			case ">" -> ">";
			default -> "<";
		};
	}
}

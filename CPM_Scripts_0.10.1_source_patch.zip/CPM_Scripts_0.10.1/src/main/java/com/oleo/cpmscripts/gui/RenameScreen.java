package com.oleo.cpmscripts.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import com.oleo.cpmscripts.CpmScriptsClient;
import com.oleo.cpmscripts.ScriptEngine;

/** Диалог переименования скрипта/графа. */
public class RenameScreen extends Screen {
	private final Screen parent;
	private final String oldName;
	private EditBox input;

	private final String ext;      // расширение скрыто из поля и дописывается обратно
	private final boolean isNode;

	public RenameScreen(Screen parent, String oldName) {
		this(parent, oldName, oldName.startsWith("nodes/"));
	}

	private RenameScreen(Screen parent, String oldName, boolean isNode) {
		super(Component.literal("Переименовать"));
		this.parent = parent;
		this.isNode = isNode;
		String base = isNode ? oldName.substring("nodes/".length()) : oldName;
		this.ext = base.endsWith(".json") ? ".json" : base.endsWith(".lua") ? ".lua" : "";
		this.oldName = oldName;
	}

	private String baseShown() {
		String base = isNode ? oldName.substring("nodes/".length()) : oldName;
		return ext.isEmpty() ? base : base.substring(0, base.length() - ext.length());
	}

	@Override
	protected void init() {
		input = new EditBox(this.font, this.width / 2 - 150, this.height / 2 - 30, 300, 18, Component.literal("имя"));
		input.setValue(baseShown());
		input.setFocused(true);
		input.moveCursorToEnd(false);
		input.setHighlightPos(0); // весь текст выделен — печатаешь сразу, без клика
		setInitialFocus(input);
		addRenderableWidget(input);
		addRenderableWidget(new FlatButton(this.width / 2 - 150, this.height / 2 + 4, 145, 18,
				Component.literal("Переименовать"), b -> apply(), 0xFF23332E, 0xFF2E453D, GuiStyle.ON));
		addRenderableWidget(new FlatButton(this.width / 2 + 5, this.height / 2 + 4, 145, 18,
				Component.literal("Отмена"), b -> onClose()));
	}

	private void apply() {
		String newName = input.getValue().trim() + ext;
		if (isNode) newName = "nodes/" + newName;
		String err = ScriptEngine.renameScript(oldName, newName);
		if (err != null) {
			CpmScriptsClient.chat("Переименование: " + err);
			return;
		}
		Minecraft.getInstance().setScreen(parent);
		if (parent instanceof ScriptListScreen sl)
			sl.resize(sl.width, sl.height); // пересобрать список (rebuildWidgets protected)
	}

	@Override
	public boolean keyPressed(net.minecraft.client.input.KeyEvent evt) {
		if (evt.key() == 257) { apply(); return true; } // Enter
		return super.keyPressed(evt);
	}

	@Override
	public void render(GuiGraphics gg, int mouseX, int mouseY, float partialTick) {
		GuiStyle.background(gg, this.width, this.height);
		GuiStyle.header(gg, this.font, this.width, "Переименовать", oldName);
		gg.drawCenteredString(this.font, "Новое имя:", this.width / 2, this.height / 2 - 44, GuiStyle.MUTED);
		super.render(gg, mouseX, mouseY, partialTick);
	}

	@Override
	public void onClose() {
		Minecraft.getInstance().setScreen(parent);
	}
}

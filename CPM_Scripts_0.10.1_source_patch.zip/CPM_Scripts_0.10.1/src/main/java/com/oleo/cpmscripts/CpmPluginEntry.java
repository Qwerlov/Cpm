package com.oleo.cpmscripts;

import com.tom.cpm.api.IClientAPI;
import com.tom.cpm.api.ICPMPlugin;
import com.tom.cpm.api.ICommonAPI;

/**
 * Entry point discovered by CustomPlayerModels (fabric.mod.json -> "cpmapi").
 * Captures the CPM client API so scripts can drive value layers.
 */
public class CpmPluginEntry implements ICPMPlugin {

	@Override
	public void initClient(IClientAPI api) {
		CpmBridge.api = api;
		CpmScriptsClient.LOGGER.info("[CPM Scripts] CPM API connected");
	}

	@Override
	public void initCommon(ICommonAPI api) {
		// nothing needed on the common side
	}

	@Override
	public String getOwnerModId() {
		return "cpmscripts";
	}
}

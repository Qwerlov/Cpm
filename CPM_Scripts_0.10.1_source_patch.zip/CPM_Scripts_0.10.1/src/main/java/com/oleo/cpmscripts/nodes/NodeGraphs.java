package com.oleo.cpmscripts.nodes;

import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import com.oleo.cpmscripts.ScriptEngine;
import com.oleo.cpmscripts.nodes.GraphCompiler.CompileException;

/**
 * Хранилище графов нод: config/cpmscripts/nodes/*.json.
 * Список/сохранение/удаление + компиляция в Lua для ScriptEngine.
 */
public final class NodeGraphs {
	private NodeGraphs() {}

	public static Path dir() {
		return ScriptEngine.getScriptsDir().resolve("nodes");
	}

	/** Папка с .cpmproject для списков анимаций/слоёв в нодах. */
	public static Path projectsDir() {
		return ScriptEngine.getScriptsDir().resolve("projects");
	}

	public static Path file(String name) {
		if (!name.endsWith(".json")) name = name + ".json";
		return dir().resolve(name).normalize();
	}

	public static List<String> list() {
		List<String> out = new ArrayList<>();
		try {
			Files.createDirectories(dir());
			try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir(), "*.json")) {
				for (Path f : ds) out.add(f.getFileName().toString());
			}
		} catch (IOException ignored) {}
		out.sort(String.CASE_INSENSITIVE_ORDER);
		return out;
	}

	public static NodeGraph load(String name) throws IOException {
		return NodeGraph.load(file(name));
	}

	public static void save(NodeGraph g) throws IOException {
		Files.createDirectories(dir());
		g.save(file(g.name));
	}

	public static void delete(String name) throws IOException {
		Files.deleteIfExists(file(name));
	}

	/** Lua-код для графа (для загрузки в движок или показа в редакторе). */
	public static String compile(String name) throws IOException, CompileException {
		NodeGraph g = load(name);
		return GraphCompiler.compile(g);
	}
}

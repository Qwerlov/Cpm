package com.oleo.cpmscripts.gui;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;

import com.tom.cpl.gui.Frame;
import com.tom.cpl.gui.elements.FileChooserPopup;
import com.tom.cpl.util.EmbeddedLocalization;
import com.tom.cpm.client.GuiImpl;

import net.fabricmc.loader.api.FabricLoader;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;

/**
 * Экран с РОДНЫМ окном выбора файла CPM (FileChooserPopup внутри CPM GuiImpl).
 * Используется, только если CPM загружен — иначе ScriptListScreen открывает FilePickScreen.
 */
public class CpmFilePickScreen extends GuiImpl {

	public CpmFilePickScreen(Screen parent) {
		super(gui -> new Frame(gui) {
			@Override
			public void initFrame(int width, int height) {
				FileChooserPopup fc = new FileChooserPopup(this);
				// Свои тексты через loc(): CPM после загрузки обнуляет allEntries,
				// поэтому сначала ремонтируем список рефлексией, потом конструируем.
				fc.setTitle(loc("Выбери .lua скрипт"));
				fc.setFileDescText(loc("Lua scripts (*.lua)"));
				fc.setCurrentDirectory(FabricLoader.getInstance().getGameDir().toFile());
				fc.setFilter(new FileChooserPopup.FileFilter("lua"));
				fc.setButtonText("Select");
				fc.setAccept((File f) -> {
					if (f != null) {
						String err = com.oleo.cpmscripts.ScriptEngine.addScriptFrom(f.toPath());
						if (err != null) com.oleo.cpmscripts.CpmScriptsClient.chat("Ошибка копирования: " + err);
					}
					Minecraft.getInstance().setScreen(parent);
				});
				fc.setOnClosed(() -> Minecraft.getInstance().setScreen(parent));
				openPopup(fc);
			}
		}, parent);
	}

	/**
	 * Своя локализация с текстом как есть. CPM после своей загрузки обнуляет
	 * статический список allEntries, из-за чего конструктор падает с NPE —
	 * поэтому перед созданием возвращаем список на место.
	 */
	private static EmbeddedLocalization loc(String text) {
		repairAllEntries();
		EmbeddedLocalization e = new EmbeddedLocalization(text) {};
		e.setFallback(text);
		return e;
	}

	private static void repairAllEntries() {
		try {
			Field f = EmbeddedLocalization.class.getDeclaredField("allEntries");
			f.setAccessible(true);
			if (f.get(null) == null) f.set(null, new ArrayList<EmbeddedLocalization>());
		} catch (Throwable ignored) {}
	}
}

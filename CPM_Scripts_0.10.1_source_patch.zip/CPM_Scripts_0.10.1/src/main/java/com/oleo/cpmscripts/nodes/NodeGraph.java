package com.oleo.cpmscripts.nodes;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;

/**
 * Модель графа нод + JSON-сериализация.
 * Файл: config/cpmscripts/nodes/<имя>.json
 */
public final class NodeGraph {
	public static final int FORMAT = 1;

	public int format = FORMAT;
	public String name = "";
	public final List<GNode> nodes = new ArrayList<>();
	public final List<GWire> wires = new ArrayList<>();

	public static final class GNode {
		public String id;          // уникальный в графе: "n1", "n2"...
		public String type;        // id типа из NodeTypes
		public int x, y;           // позиция на канвасе
		public String group;       // id группы: ноды с одинаковым group двигаются вместе
		public final Map<String, String> params = new LinkedHashMap<>();
	}

	public static final class GWire {
		public String fromNode;    // выходной порт
		public String fromPort;
		public String toNode;      // входной порт
		public String toPort;
	}

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	public GNode nodeById(String id) {
		for (GNode n : nodes) if (n.id.equals(id)) return n;
		return null;
	}

	/** Следующий свободный id вида n1, n2... */
	public String nextId() {
		int i = 1;
		while (nodeById("n" + i) != null) i++;
		return "n" + i;
	}

	public void removeNode(String id) {
		nodes.removeIf(n -> n.id.equals(id));
		wires.removeIf(w -> w.fromNode.equals(id) || w.toNode.equals(id));
	}

	public void removeWire(String fromNode, String fromPort, String toNode, String toPort) {
		wires.removeIf(w -> w.fromNode.equals(fromNode) && w.fromPort.equals(fromPort)
				&& w.toNode.equals(toNode) && w.toPort.equals(toPort));
	}

	public static NodeGraph load(Path file) throws IOException, JsonParseException {
		try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
			NodeGraph g = GSON.fromJson(r, NodeGraph.class);
			if (g == null) throw new IOException("пустой файл");
			if (g.format < 1 || g.format > FORMAT) throw new IOException("неподдерживаемый формат " + g.format);
			g.name = file.getFileName().toString().replaceFirst("\\.json$", "");
			return g;
		}
	}

	public void save(Path file) throws IOException {
		try (Writer w = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
			GSON.toJson(this, w);
		}
	}

	/** Снапшот для Ctrl+Z. */
	public String toJson() {
		return GSON.toJson(this);
	}

	/** Восстановление из снапшота. */
	public static NodeGraph fromJson(String json) {
		NodeGraph g = GSON.fromJson(json, NodeGraph.class);
		if (g == null) throw new IllegalStateException("пустой снапшот");
		return g;
	}
}

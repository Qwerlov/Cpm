package com.oleo.cpmscripts.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Диалог при выходе из редактора с несохранёнными изменениями. */
public class SaveConfirmScreen extends Screen {
	private final Screen parent;
	private final Runnable onSave;
	private final Runnable onDiscard;

	public SaveConfirmScreen(Screen parent, Runnable onSave, Runnable onDiscard) {
		super(Component.literal("Сохранить изменения?"));
		this.parent = parent;
		this.onSave = onSave;
		this.onDiscard = onDiscard;
	}

	@Override
	protected void init() {
		int w = 110, gap = 10, total = w * 3 + gap * 2;
		int x = this.width / 2 - total / 2, y = this.height / 2 + 4;
		addRenderableWidget(new FlatButton(x, y, w, 18,
				Component.literal("Сохранить"), b -> { onSave.run(); },
				0xFF23332E, 0xFF2E453D, GuiStyle.ON));
		addRenderableWidget(new FlatButton(x + w + gap, y, w, 18,
				Component.literal("Не сохранять"), b -> { onDiscard.run(); },
				0xFF3A2626, 0xFF4E3030, GuiStyle.ERROR));
		addRenderableWidget(new FlatButton(x + (w + gap) * 2, y, w, 18,
				Component.literal("Отмена"), b -> Minecraft.getInstance().setScreen(parent)));
	}

	@Override
	public void render(GuiGraphics gg, int mouseX, int mouseY, float partialTick) {
		parent.render(gg, -1, -1, partialTick); // фон — редактор
		gg.fill(0, 0, this.width, this.height, 0xA0000000);
		gg.drawCenteredString(this.font, "Сохранить изменения перед выходом?", this.width / 2,
				this.height / 2 - 14, GuiStyle.TEXT);
		super.render(gg, mouseX, mouseY, partialTick);
	}

	@Override
	public boolean keyPressed(net.minecraft.client.input.KeyEvent evt) {
		if (evt.key() == 256) { Minecraft.getInstance().setScreen(parent); return true; }
		return super.keyPressed(evt);
	}

	@Override
	public boolean isPauseScreen() { return false; }
}

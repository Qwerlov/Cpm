package com.oleo.cpmscripts.gui;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import com.oleo.cpmscripts.nodes.NodeLists;

/**
 * Выбор значения параметра ноды.
 * Режим списка (dropdown/анимации/слои/предметы — с поиском) или ввода (число/текст).
 */
public class NodeParamScreen extends Screen {
	private final Screen parent;
	private final String title;
	private final List<String> options;   // null = режим ввода
	private final String initial;
	private final boolean numberMode;
	private final Consumer<String> callback;

	private EditBox search;
	private EditBox input;
	private List<String> filtered = new ArrayList<>();
	private String selected;
	private int scrollOffset = 0;

	public NodeParamScreen(Screen parent, String title, List<String> options,
			String initial, boolean numberMode, Consumer<String> callback) {
		super(Component.literal(title));
		this.parent = parent;
		this.title = title;
		this.options = options;
		this.initial = initial == null ? "" : initial;
		this.numberMode = numberMode;
		this.callback = callback;
		this.selected = this.initial;
	}

	private boolean smallList() { return options != null && options.size() <= 30; }

	private static String fmtNum(String s) {
		return s.endsWith(".0") ? s.substring(0, s.length() - 2) : s;
	}

	protected void init() {
		if (options != null) {
			if (!smallList()) { // большой список — с поиском
				search = new EditBox(this.font, this.width / 2 - 150, 34, 300, 16, Component.literal("поиск"));
				search.setHint(Component.literal("поиск..."));
				search.setResponder(value -> refilter());
				addRenderableWidget(search);
				refilter();
			} else {
				filtered.clear();
				filtered.addAll(options);
			}
		} else {
			input = new EditBox(this.font, this.width / 2 - 150, 40, 300, 18, Component.literal("значение"));
			input.setValue(numberMode ? fmtNum(initial) : initial);
			addRenderableWidget(input);
			setInitialFocus(input);
		}
		addRenderableWidget(new FlatButton(this.width / 2 - 150, this.height - 30, 145, 18,
				Component.literal("OK"), b -> apply()));
		addRenderableWidget(new FlatButton(this.width / 2 + 5, this.height - 30, 145, 18,
				Component.literal("Отмена"), b -> onClose()));
	}

	private void refilter() {
		filtered.clear();
		String q = search == null ? "" : search.getValue().toLowerCase(Locale.ROOT);
		for (String o : options) {
			if (q.isEmpty() || o.toLowerCase(Locale.ROOT).contains(q)) filtered.add(o);
				if (filtered.size() >= 500) break;
		}
		scrollOffset = Math.max(0, Math.min(scrollOffset, maxScrollRows()));
	}

	private int listStartY() { return search != null ? 58 : 40; }
	private int visibleRows() { return Math.max(0, (this.height - 40 - listStartY()) / 14); }
	private int maxScrollRows() { return Math.max(0, filtered.size() - visibleRows()); }

	private void apply() {
		if (options != null) {
			String v = selected;
			// если ничего не выбрано (или выбор не менялся), берём точное совпадение
			// из поиска, иначе первый отфильтрованный вариант
			if (v == null || v.isEmpty() || v.equals(initial)) {
				String q = search == null ? "" : search.getValue().trim().toLowerCase(Locale.ROOT);
				if (!q.isEmpty()) {
					String first = null;
					for (String o : filtered) {
						if (first == null) first = o;
						if (o.toLowerCase(Locale.ROOT).equals(q)) { first = o; break; }
					}
					if (first == null) refilter();
					if (first == null && !filtered.isEmpty()) first = filtered.get(0);
					if (first != null) v = first;
				}
			}
			if (v != null && !v.isEmpty()) callback.accept(v);
		} else {
			String v = input.getValue().trim().replace(',', '.');
			if (numberMode) {
				try {
					Double.parseDouble(v);
				} catch (NumberFormatException e) { onClose(); return; }
			}
			callback.accept(v);
		}
		onClose();
	}

	public void render(GuiGraphics gg, int mouseX, int mouseY, float partialTick) {
		GuiStyle.background(gg, this.width, this.height);
		GuiStyle.header(gg, this.font, this.width, title, options != null
				? "вариантов: " + filtered.size() : numberMode ? "число" : "текст");

		if (options != null) {
			int y = listStartY();
			int x = this.width / 2 - 150;
			int endY = this.height - 40;
			gg.enableScissor(x, y, x + 300, endY);
			int end = Math.min(filtered.size(), scrollOffset + visibleRows());
			for (int i = scrollOffset; i < end; i++) {
				String o = filtered.get(i);
				int rowY = y + (i - scrollOffset) * 14;
				boolean sel = o.equals(selected);
				boolean hover = mouseX >= x && mouseX < x + 300 && mouseY >= rowY && mouseY < rowY + 13;
				gg.fill(x, rowY, x + 300, rowY + 13, hover ? GuiStyle.BTN_HOVER : sel ? 0xFF23403A : GuiStyle.BTN);
				gg.drawString(this.font, o, x + 4, rowY + 3, sel ? GuiStyle.ON : GuiStyle.TEXT);
			}
			gg.disableScissor();
			if (filtered.size() > visibleRows()) {
				gg.drawString(this.font, "Колесо: прокрутка · " + (scrollOffset + 1) + "–" + Math.min(filtered.size(), scrollOffset + visibleRows()) + "/" + filtered.size(), x, endY + 2, GuiStyle.MUTED);
			}
			if (filtered.isEmpty()) {
				gg.drawCenteredString(this.font, "Ничего не найдено", this.width / 2, 70, GuiStyle.MUTED);
			}
		}

		super.render(gg, mouseX, mouseY, partialTick);
	}

	public boolean mouseClicked(net.minecraft.client.input.MouseButtonEvent evt, boolean doubleClick) {
		double mx = evt.x(), my = evt.y();
		int btn = evt.button();
		int startY = listStartY();
		if (options != null && btn == 0 && my >= startY && my < this.height - 40
				&& mx >= this.width / 2 - 150 && mx < this.width / 2 + 150) {
			int idx = scrollOffset + ((int) my - startY) / 14;
			if (idx >= scrollOffset && idx < Math.min(filtered.size(), scrollOffset + visibleRows())) {
				selected = filtered.get(idx);
				apply();
				return true;
			}
		}
		return super.mouseClicked(evt, doubleClick);
	}

	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
		if (options != null) {
			if (mouseY >= listStartY() && mouseY < this.height - 40) {
				scrollOffset = Math.max(0, Math.min(maxScrollRows(), scrollOffset - (int) Math.signum(scrollY) * Math.max(1, (int) Math.ceil(Math.abs(scrollY) * 3))));
				return true;
			}
			return true;
		}
		return super.mouseScrolled(mouseX, mouseY, scrollX, scrollY);
	}

	public boolean keyPressed(net.minecraft.client.input.KeyEvent evt) {
		if (evt.key() == 257) { apply(); return true; } // Enter: применить (ввод или лучшее совпадение из списка)
		return super.keyPressed(evt);
	}

	public void onClose() {
		Minecraft.getInstance().setScreen(parent);
	}

	public boolean isPauseScreen() { return false; }

	// --- фабрики для видов параметров ---
	public static NodeParamScreen dropdown(Screen parent, String title, List<String> ids, List<String> labels, String current, Consumer<String> cb) {
		return new NodeParamScreen(parent, title, labels, labelToId(ids, labels, current), false,
				v -> cb.accept(labelToId(labels, ids, v)));
	}

	private static String labelToId(List<String> from, List<String> to, String v) {
		int i = from.indexOf(v);
		return i >= 0 && i < to.size() ? to.get(i) : v;
	}

	public static NodeParamScreen anims(Screen parent, String current, Consumer<String> cb) {
		NodeLists.refreshProjects();
		return new NodeParamScreen(parent, "Анимация", NodeLists.anims(), current, false, cb);
	}

	public static NodeParamScreen layers(Screen parent, String current, Consumer<String> cb) {
		NodeLists.refreshProjects();
		return new NodeParamScreen(parent, "Value-слой", NodeLists.layers(), current, false, cb);
	}

	public static NodeParamScreen items(Screen parent, String current, Consumer<String> cb) {
		return new NodeParamScreen(parent, "Предмет", NodeLists.items(), current, false, cb);
	}

	public static NodeParamScreen number(Screen parent, String title, double current, Consumer<String> cb) {
		List<String> none = null;
		return new NodeParamScreen(parent, title, none, String.valueOf(current), true, cb);
	}

	public static NodeParamScreen text(Screen parent, String title, String current, Consumer<String> cb) {
		return new NodeParamScreen(parent, title, null, current, false, cb);
	}

		public static NodeParamScreen effects(Screen parent, String current, Consumer<String> cb) {
			return new NodeParamScreen(parent, "Эффект", NodeLists.effects(), current, false, cb);
		}

		public static NodeParamScreen entities(Screen parent, String current, Consumer<String> cb) {
			return new NodeParamScreen(parent, "Тип сущности", NodeLists.entities(), current, false, cb);
		}

		public static NodeParamScreen blocks(Screen parent, String current, Consumer<String> cb) {
			return new NodeParamScreen(parent, "Блок", NodeLists.blocks(), current, false, cb);
		}
}

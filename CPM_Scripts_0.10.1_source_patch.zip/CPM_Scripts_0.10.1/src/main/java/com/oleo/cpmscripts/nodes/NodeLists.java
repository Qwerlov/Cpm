package com.oleo.cpmscripts.nodes;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;

import com.tom.cpm.client.CustomPlayerModelsClient;
import com.tom.cpm.shared.animation.AnimationRegistry;
import com.tom.cpm.shared.config.Player;
import com.tom.cpm.shared.definition.ModelDefinition;
import com.tom.cpm.shared.definition.ModelDefinitionLoader;
import com.tom.cpm.shared.model.RenderManager;
import com.tom.cpm.shared.parts.anim.menu.AbstractGestureButtonData;

/**
 * Списки для выпадающих меню нод:
 *  - анимации (жесты) и value-слои — из ТЕКУЩЕЙ модели игрока через CPM (меню жестов модели);
 *    если модель недоступна — запасной вариант: скан .cpmproject в config/cpmscripts/projects/;
 *  - предметы — из реестра игры.
 */
public final class NodeLists {
	private static List<String> anims = new ArrayList<>();
	private static List<String> layers = new ArrayList<>();
	private static List<String> items = null;
	private static String projectsInfo = "не сканировалось";

	private NodeLists() {}

	public static List<String> anims() { return anims; }
	public static List<String> layers() { return layers; }

	public static String projectsInfo() { return projectsInfo; }

	/** Обновить списки анимаций/слоёв. Возвращает текст для статуса. */
	public static synchronized String refreshProjects() {
		TreeSet<String> a = new TreeSet<>();
		TreeSet<String> l = new TreeSet<>();
		// 1) текущая модель игрока (автоматически, без папки projects)
		String modelInfo = scanCurrentModel(a, l);
		if (modelInfo != null) {
			anims = new ArrayList<>(a);
			layers = new ArrayList<>(l);
			projectsInfo = modelInfo;
			return projectsInfo;
		}
		// 2) запасной вариант: скан .cpmproject в config/cpmscripts/projects
		int files = 0;
		Path dir = NodeGraphs.projectsDir();
		try {
			Files.createDirectories(dir);
			try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir, "*.cpmproject")) {
				for (Path f : ds) {
					int[] cnt = scanProject(f, a, l);
					files += cnt[0];
				}
			}
			anims = new ArrayList<>(a);
			layers = new ArrayList<>(l);
			projectsInfo = files + " проект(ов): " + anims.size() + " анимаций, " + layers.size() + " слоёв";
		} catch (IOException e) {
			projectsInfo = "ошибка: " + e.getMessage();
		}
		return projectsInfo;
	}

	/**
	 * Анимации/слои из текущей модели игрока (меню жестов модели, как в игровом GUI CPM).
	 * Возвращает текст для статуса или null, если модель недоступна (тогда — скан папки).
	 */
	private static String scanCurrentModel(TreeSet<String> anims, TreeSet<String> layers) {
		try {
			if (!com.oleo.cpmscripts.CpmBridge.isReady()) return null;
			Minecraft mc = Minecraft.getInstance();
			if (mc.player == null) return null;
			CustomPlayerModelsClient cpm = CustomPlayerModelsClient.INSTANCE;
			if (cpm == null || cpm.manager == null) return null;
			Player<?> player = loadedPlayer(cpm.manager, mc.player.getGameProfile());
			if (player == null) return null;
			ModelDefinition def = player.getModelDefinition();
			if (def == null) return null;
			AnimationRegistry reg = def.getAnimations();
			if (reg == null) return null;
			int cnt = 0;
			// именованные действия меню (жесты/слайдеры)
			for (AbstractGestureButtonData btn : reg.getNamedActions()) {
				String name = btn.getName();
				if (name == null || name.isEmpty()) continue;
				switch (btn.getType()) {
					case GESTURE, POSE -> anims.add(name);
					default -> layers.add(name); // VALUE_PARAMETER_SLIDER / BOOL_PARAMETER_TOGGLE / DROPDOWN
				}
				cnt++;
			}
			// командные действия: сюда попадают ВСЕ играбельные анимации модели,
			// включая те, что не вынесены в меню (и value-слои с их максимумами)
			for (java.util.Map.Entry<String, ?> e : reg.getCommandActionsMap().entrySet()) {
				String name = e.getKey();
				if (name == null || name.isEmpty()) continue;
				if (!anims.contains(name) && !layers.contains(name)) {
					try {
						int max = ((com.tom.cpm.shared.parts.anim.menu.CommandAction) e.getValue()).getMaxValue();
						if (max > 0) layers.add(name); else anims.add(name);
					} catch (Throwable t) {
						anims.add(name);
					}
					cnt++;
				}
			}
			// кастомные позы
			for (String name : reg.getCustomPoses().keySet()) {
				if (name != null && !name.isEmpty() && !anims.contains(name)) {
					anims.add(name);
					cnt++;
				}
			}
			// ВАЖНО: getNamedActionByKeybind сюда НЕ добавлять — ключи там с
			// префиксами "p_"/"g_"/"l_", playAnimation их не понимает (анимация не вызывается)
			if (cnt == 0) return null; // в модели пусто — пробуем папку projects
			return "текущая модель: " + anims.size() + " анимаций, " + layers.size() + " слоёв";
		} catch (Throwable t) {
			return null; // внутренности CPM недоступны — старый способ
		}
	}

	/** Player текущего профиля: manager.loader.getLoadedPlayer(profile); loader — protected, рефлексия. */
	private static <G> Player<?> loadedPlayer(RenderManager<G, ?, ?, ?> manager, G profile) {
		try {
			java.lang.reflect.Field f = RenderManager.class.getDeclaredField("loader");
			f.setAccessible(true);
			ModelDefinitionLoader<G> loader = (ModelDefinitionLoader<G>) f.get(manager);
			return loader == null ? null : loader.getLoadedPlayer(profile);
		} catch (Throwable t) {
			return null;
		}
	}

	/** Разобрать один .cpmproject (zip): animations/*.json, name с префиксом $value$ = слой. */
	private static int[] scanProject(Path file, TreeSet<String> anims, TreeSet<String> layers) {
		int[] cnt = {0};
		try (ZipFile zip = new ZipFile(file.toFile())) {
			java.util.Enumeration<? extends ZipEntry> en = zip.entries();
			while (en.hasMoreElements()) {
				ZipEntry e = en.nextElement();
				if (e.isDirectory() || !e.getName().startsWith("animations/") || !e.getName().endsWith(".json")) continue;
				try (InputStream in = zip.getInputStream(e)) {
					JsonObject o = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
					if (!o.has("name")) continue;
					String name = o.get("name").getAsString();
					if (name.startsWith("$value$")) layers.add(name.substring("$value$".length()));
					else anims.add(name);
					cnt[0]++;
				} catch (Throwable ignored) {}
			}
		} catch (IOException ignored) {}
		return cnt;
	}

	/** Все id предметов из реестра (лениво, с кэшем). */
	public static synchronized List<String> items() {
		if (items == null) {
			TreeSet<String> s = new TreeSet<>();
			for (var item : BuiltInRegistries.ITEM) {
				s.add(String.valueOf(BuiltInRegistries.ITEM.getKey(item)));
			}
			items = new ArrayList<>(s);
		}
		return items;
	}

	private static List<String> effects = null;
	private static List<String> entities = null;
	private static List<String> blocks = null;

	public static synchronized List<String> effects() {
		if (effects == null) {
			TreeSet<String> s = new TreeSet<>();
			for (var eff : BuiltInRegistries.MOB_EFFECT) {
				s.add(String.valueOf(BuiltInRegistries.MOB_EFFECT.getKey(eff)));
			}
			effects = new ArrayList<>(s);
		}
		return effects;
	}

	public static synchronized List<String> entities() {
		if (entities == null) {
			TreeSet<String> s = new TreeSet<>();
			for (var ent : BuiltInRegistries.ENTITY_TYPE) {
				s.add(String.valueOf(BuiltInRegistries.ENTITY_TYPE.getKey(ent)));
			}
			entities = new ArrayList<>(s);
		}
		return entities;
	}

	public static synchronized List<String> blocks() {
		if (blocks == null) {
			TreeSet<String> s = new TreeSet<>();
			for (var blk : BuiltInRegistries.BLOCK) {
				s.add(String.valueOf(BuiltInRegistries.BLOCK.getKey(blk)));
			}
			blocks = new ArrayList<>(s);
		}
		return blocks;
	}
}

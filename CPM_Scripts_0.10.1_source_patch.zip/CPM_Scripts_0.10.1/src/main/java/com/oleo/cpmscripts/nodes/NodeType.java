package com.oleo.cpmscripts.nodes;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Описание типа ноды: порты (входы/выходы) и параметры.
 * Порты типизированы: BOOL или NUMBER. Провода соединяют только порты одного типа.
 */
public final class NodeType {
	public enum PType { BOOL, NUMBER, STRING }
	public enum PKind { DROPDOWN, NUMBER, TEXT, ANIM, LAYER, ITEM, EFFECT, ENTITY, BLOCK }

	public static final class Port {
		public final String id;
		public final String label;
		public final PType type;
		Port(String id, String label, PType type) {
			this.id = id; this.label = label; this.type = type;
		}
	}

	public static final class Param {
		public final String id;
		public final String label;
		public final PKind kind;
		public final List<String> options;   // для DROPDOWN: id вариантов
		public final List<String> optLabels; // для DROPDOWN: подписи (рус.)
		public final double def;             // для NUMBER
		public final double min, max;        // для NUMBER
		public final String defText;         // для TEXT
		Param(String id, String label, PKind kind, List<String> options, List<String> optLabels,
				double def, double min, double max, String defText) {
			this.id = id; this.label = label; this.kind = kind;
			this.options = options == null ? Collections.emptyList() : options;
			this.optLabels = optLabels == null ? Collections.emptyList() : optLabels;
			this.def = def; this.min = min; this.max = max;
			this.defText = defText == null ? "" : defText;
		}
	}

	public final String id;        // lua-ид типа: item_held, and, timer...
	public final String title;     // русская подпись
	public final String category;  // Входы / Логика / Время / Константы / Действия
	public final List<Port> inputs = new ArrayList<>();
	public final List<Port> outputs = new ArrayList<>();
	public final List<Param> params = new ArrayList<>();
	public final int defW;         // ширина ноды на канвасе

	private NodeType(String id, String title, String category, int defW) {
		this.id = id; this.title = title; this.category = category; this.defW = defW;
	}

	public static NodeType create(String id, String title, String category) {
		return new NodeType(id, title, category, 120);
	}

	public NodeType in(String id, String label, PType type) {
		inputs.add(new Port(id, label, type));
		return this;
	}

	public NodeType out(String id, String label, PType type) {
		outputs.add(new Port(id, label, type));
		return this;
	}

	public NodeType param(Param p) {
		params.add(p);
		return this;
	}

	// --- фабрики параметров ---
	public static Param dropdown(String id, String label, String[] ids, String[] labels, String def) {
		List<String> o = new ArrayList<>(), l = new ArrayList<>();
		Collections.addAll(o, ids); Collections.addAll(l, labels);
		return new Param(id, label, PKind.DROPDOWN, o, l, 0, 0, 0, def);
	}

	public static Param num(String id, String label, double def, double min, double max) {
		return new Param(id, label, PKind.NUMBER, null, null, def, min, max, null);
	}

	public static Param text(String id, String label, String def) {
		return new Param(id, label, PKind.TEXT, null, null, 0, 0, 0, def);
	}

	public static Param anim(String id, String label) {
		return new Param(id, label, PKind.ANIM, null, null, 0, 0, 0, "");
	}

	public static Param layer(String id, String label) {
		return new Param(id, label, PKind.LAYER, null, null, 0, 0, 0, "");
	}

	public static Param item(String id, String label) {
		return new Param(id, label, PKind.ITEM, null, null, 0, 0, 0, "minecraft:stick");
	}

	public Param paramById(String pid) {
		for (Param p : params) if (p.id.equals(pid)) return p;
		return null;
	}

	public Port inputById(String pid) {
		for (Port p : inputs) if (p.id.equals(pid)) return p;
		return null;
	}

	public Port outputById(String pid) {
		for (Port p : outputs) if (p.id.equals(pid)) return p;
		return null;
	}

		public static Param effect(String id, String label) {
			return new Param(id, label, PKind.EFFECT, null, null, 0, 0, 0, "minecraft:speed");
		}

		public static Param entity(String id, String label) {
			return new Param(id, label, PKind.ENTITY, null, null, 0, 0, 0, "");
		}

		public static Param block(String id, String label) {
			return new Param(id, label, PKind.BLOCK, null, null, 0, 0, 0, "");
		}
}

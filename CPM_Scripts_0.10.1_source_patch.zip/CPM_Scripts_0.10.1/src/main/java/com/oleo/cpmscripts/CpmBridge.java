package com.oleo.cpmscripts;

import com.tom.cpm.api.IClientAPI;

/**
 * Bridge to CustomPlayerModels. Sets value-layer values for the local player.
 * Layers are addressed by their name without the "$value$" prefix
 * (same names as in /cpmclient animate <name> <0-255>).
 */
public final class CpmBridge {
	static volatile IClientAPI api;

	private CpmBridge() {}

	public static boolean isReady() {
		return api != null;
	}

	/** Set a value layer (0..255). Returns false if CPM or the layer is missing. */
	public static boolean setValue(String name, int value) {
		IClientAPI a = api;
		if (a == null) return false;
		if (value < 0) value = 0;
		if (value > 255) value = 255;
		try {
			return a.playAnimation(name, value);
		} catch (Throwable t) {
			return false;
		}
	}

	/** Read current value of a layer, -1 if unknown. */
	public static int getValue(String name) {
		IClientAPI a = api;
		if (a == null) return -1;
		try {
			return a.getAnimationPlaying(name);
		} catch (Throwable t) {
			return -1;
		}
	}

	/** Start a regular (gesture) animation by name. Идемпотентно:
	 *  playAnimation(name) в CPM — тоггл, поэтому повторный вызов гасил бы анимацию. */
	public static boolean play(String name) {
		IClientAPI a = api;
		if (a == null) return false;
		try {
			if (a.getAnimationPlaying(name) > 0) return true; // уже играет
			return a.playAnimation(name);
		} catch (Throwable t) {
			return false;
		}
	}

	/** Stop a regular animation started via play(). Останавливает только её. */
	public static boolean stop(String name) {
		IClientAPI a = api;
		if (a == null) return false;
		try {
			if (a.getAnimationPlaying(name) == 0) return true; // и так не играет
			return a.playAnimation(name, 0);
		} catch (Throwable t) {
			return false;
		}
	}
}

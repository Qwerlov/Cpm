package com.oleo.cpmscripts.nodes;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.oleo.cpmscripts.nodes.NodeType.PType;

/**
 * Каталог всех типов нод. Порядок в списке = порядок в контекстном меню редактора.
 * Генератор Lua: GraphCompiler (тот же каталог, по id типа).
 */
public final class NodeTypes {
	public static final Map<String, NodeType> ALL = new LinkedHashMap<>();
	public static final List<String> CATEGORIES = List.of("Входы", "Логика", "Время", "Константы", "Действия");

	static {
		// ================= ВХОДЫ (источники сигнала, выход BOOL) =================
		reg(NodeType.create("item_held", "Предмет в руке", "Входы")
			.out("out", "есть", PType.BOOL)
			.param(NodeType.item("item", "Предмет"))
			.param(NodeType.dropdown("hand", "Рука",
				new String[]{"main", "off", "any"},
				new String[]{"Основная", "Вторая", "Любая"}, "main")));

		reg(NodeType.create("item_use", "Использование предмета", "Входы")
			.out("out", "использует", PType.BOOL)
			.param(NodeType.item("item", "Предмет"))
			.param(NodeType.dropdown("mode", "Режим",
				new String[]{"while", "press"},
				new String[]{"Пока использует", "По началу использования"}, "while")));

		reg(NodeType.create("chat_in", "Чат: сообщение", "Входы")
			.out("new", "новое сообщение", PType.BOOL)
			.out("msg", "текст", PType.STRING)
			.out("num", "число в тексте", PType.NUMBER));

		reg(NodeType.create("chat_match", "Проверка строки", "Логика")
			.in("msg", "текст (пусто = чат)", PType.STRING)
			.in("find", "образец (пусто = параметр)", PType.STRING)
			.out("out", "совпало", PType.BOOL)
			.param(NodeType.text("text", "Фраза", ""))
			.param(NodeType.dropdown("mode", "Тип совпадения",
				new String[]{"partial", "full"},
				new String[]{"Частичное (содержит)", "Полное (равно)"}, "partial")));

		reg(NodeType.create("equip", "Надето (броня)", "Входы")
			.out("out", "надето", PType.BOOL)
			.param(NodeType.dropdown("slot", "Слот",
				new String[]{"head", "chest", "legs", "feet"},
				new String[]{"Голова", "Грудь", "Ноги", "Ступни"}, "feet"))
			.param(NodeType.item("item", "Предмет")));

		reg(NodeType.create("effect", "Эффект зелья", "Входы")
			.out("has", "есть эффект", PType.BOOL)
			.out("amp", "уровень (0+)", PType.NUMBER)
			.param(NodeType.effect("effect", "Эффект")));

		reg(NodeType.create("entities", "Сущности рядом", "Входы")
			.out("count", "количество", PType.NUMBER)
			.out("has", "есть рядом", PType.BOOL)
			.param(NodeType.entity("type", "Тип (пусто = все)"))
			.param(NodeType.text("name", "Имя содержит (пусто = все)", ""))
			.param(NodeType.num("radius", "Радиус", 8, 1, 64)));

		reg(NodeType.create("key", "Кейбинд", "Входы")
			.out("out", "нажат", PType.BOOL)
			.param(NodeType.text("n", "Клавиша (g, space...)", "g"))
			.param(NodeType.dropdown("mode", "Режим",
				new String[]{"down", "pressed"},
				new String[]{"Зажата", "По нажатию"}, "down")));

		reg(NodeType.create("mouse", "Мышь", "Входы")
			.out("attack", "ЛКМ зажата", PType.BOOL)
			.out("attackPress", "ЛКМ нажата", PType.BOOL)
			.out("attackRelease", "ЛКМ отпущена", PType.BOOL)
			.out("use", "ПКМ зажата", PType.BOOL)
			.out("usePress", "ПКМ нажата", PType.BOOL)
			.out("useRelease", "ПКМ отпущена", PType.BOOL));

		reg(NodeType.create("hit", "Удар попал", "Входы")
				.out("entity", "по существу", PType.BOOL)
				.out("block", "по блоку", PType.BOOL));

		reg(NodeType.create("block_use", "Блок: взаимодействие", "Входы")
			.out("new", "кликнул по блоку", PType.BOOL)
			.out("id", "id блока", PType.STRING)
			.out("match", "совпало", PType.BOOL)
			.param(NodeType.block("block", "Блок (пусто = любой)")));

		reg(NodeType.create("pose", "Поза / состояние", "Входы")
			.out("out", "активно", PType.BOOL)
			.param(NodeType.dropdown("state", "Состояние",
				new String[]{"sneak", "walking", "sprint", "swim", "crawl", "sleep", "elytra", "ride", "falling", "onGround", "inWater", "onFire"},
				new String[]{"Крадётся", "Идёт пешком", "Бежит", "Плавает", "Ползёт", "Лежит (спит)", "Элитры", "Едет на транспорте",
					"Падает", "На земле", "В воде", "Горит"}, "sneak")));

		reg(NodeType.create("vital", "Здоровье / голод / воздух", "Входы")
			.out("out", "верно", PType.BOOL)
			.param(NodeType.dropdown("stat", "Показатель",
				new String[]{"health", "food", "air", "saturation", "absorption"},
				new String[]{"Здоровье", "Голод", "Воздух", "Насыщение", "Поглощение"}, "health"))
			.param(NodeType.dropdown("cmp", "Сравнение",
				new String[]{"<", "<=", "==", ">=", ">"},
				new String[]{"<", "≤", "=", "≥", ">"}, "<="))
			.param(NodeType.num("value", "Порог", 10, 0, 1000)));

		reg(NodeType.create("move", "Движение", "Входы")
			.out("out", "движется", PType.BOOL)
			.param(NodeType.num("speed", "Порог скорости, блок/тик", 0.05, 0, 2)));

		// ================= ЛОГИКА (BOOL -> BOOL) =================
		reg(NodeType.create("and", "И (AND)", "Логика")
			.in("a", "A", PType.BOOL).in("b", "B", PType.BOOL).out("out", "A и B", PType.BOOL));
		reg(NodeType.create("or", "ИЛИ (OR)", "Логика")
			.in("a", "A", PType.BOOL).in("b", "B", PType.BOOL).out("out", "A или B", PType.BOOL));
		reg(NodeType.create("not", "НЕ (NOT)", "Логика")
			.in("in", "вход", PType.BOOL).out("out", "не вход", PType.BOOL));
		reg(NodeType.create("xor", "Искл. ИЛИ (XOR)", "Логика")
			.in("a", "A", PType.BOOL).in("b", "B", PType.BOOL).out("out", "A xor B", PType.BOOL));
		reg(NodeType.create("nor", "НЕ-ИЛИ (NOR)", "Логика")
			.in("a", "A", PType.BOOL).in("b", "B", PType.BOOL).out("out", "не (A или B)", PType.BOOL));
		reg(NodeType.create("nand", "НЕ-И (NAND)", "Логика")
			.in("a", "A", PType.BOOL).in("b", "B", PType.BOOL).out("out", "не (A и B)", PType.BOOL));

		reg(NodeType.create("edge", "Фронт (стало истинно)", "Логика")
			.in("in", "вход", PType.BOOL).out("out", "импульс", PType.BOOL));

		reg(NodeType.create("toggle", "Триггер (переключатель)", "Логика")
			.in("in", "переключить", PType.BOOL).out("out", "состояние", PType.BOOL));

		reg(NodeType.create("latch", "Защёлка (Set/Reset)", "Логика")
			.in("set", "Set", PType.BOOL).in("reset", "Reset", PType.BOOL).out("out", "состояние", PType.BOOL));

		// ================= ВРЕМЯ =================
		reg(NodeType.create("timer", "Таймер (удержание)", "Время")
			.in("in", "вход", PType.BOOL).out("out", "истина", PType.BOOL)
			.param(NodeType.num("sec", "Секунд удержания", 2, 0.05, 60)));

		reg(NodeType.create("delay", "Задержка", "Время")
			.in("in", "вход", PType.BOOL).out("out", "истина", PType.BOOL)
			.param(NodeType.num("sec", "Секунд задержки", 1, 0.05, 60)));

		reg(NodeType.create("cooldown", "Cooldown (не чаще N сек)", "Время")
			.in("in", "вход", PType.BOOL).out("out", "пропущено", PType.BOOL)
			.param(NodeType.num("sec", "Пауза, сек", 3, 0.1, 600)));

		reg(NodeType.create("cycle", "Цикл (каждые N тиков)", "Время")
			.in("in", "вход (гейт)", PType.BOOL).out("out", "импульс", PType.BOOL)
			.param(NodeType.num("ticks", "Период, тиков", 20, 2, 1200)));

		// ================= КОНСТАНТЫ =================
		reg(NodeType.create("const_num", "Число", "Константы")
			.out("out", "значение", PType.NUMBER)
			.param(NodeType.num("value", "Значение", 128, 0, 255)));

		reg(NodeType.create("compare", "Сравнение чисел", "Константы")
			.in("a", "A", PType.NUMBER).in("b", "B", PType.NUMBER).out("out", "верно", PType.BOOL)
			.param(NodeType.dropdown("cmp", "Операция",
				new String[]{"<", "<=", "==", ">=", ">"},
				new String[]{"<", "≤", "=", "≥", ">"}, ">=")));

		// ================= ДЕЙСТВИЯ =================
		reg(NodeType.create("play", "Проиграть анимацию", "Действия")
			.in("in", "вход", PType.BOOL)
			.param(NodeType.anim("anim", "Анимация"))
			.param(NodeType.dropdown("mode", "Режим",
				new String[]{"once", "while"},
				new String[]{"По срабатыванию", "Пока истинно (стоп при сбросе)"}, "once")));

		reg(NodeType.create("stop", "Остановить анимацию", "Действия")
			.in("in", "вход", PType.BOOL)
			.param(NodeType.anim("anim", "Анимация")));

		reg(NodeType.create("set_layer", "Установить value-слой", "Действия")
			.in("in", "вход", PType.BOOL).in("value", "значение", PType.NUMBER)
			.param(NodeType.layer("layer", "Слой"))
			.param(NodeType.dropdown("mode", "Режим",
				new String[]{"while", "once"},
				new String[]{"Пока истинно", "По срабатыванию"}, "while"))
			.param(NodeType.dropdown("release", "При сбросе входа",
				new String[]{"nothing", "reset"},
				new String[]{"Ничего", "Сброс слоя в 128"}, "nothing")));

		reg(NodeType.create("chat", "Сообщение в чат", "Действия")
			.in("in", "вход", PType.BOOL)
			.param(NodeType.text("text", "Текст", "привет!"))
			.param(NodeType.dropdown("target", "Куда",
				new String[]{"self", "server"},
				new String[]{"Только себе (в чат)", "Отправить на сервер"}, "self")));
	}

	private static void reg(NodeType t) {
		ALL.put(t.id, t);
	}

	public static NodeType byId(String id) {
		return ALL.get(id);
	}

	public static List<NodeType> byCategory(String cat) {
		List<NodeType> l = new ArrayList<>();
		for (NodeType t : ALL.values()) if (t.category.equals(cat)) l.add(t);
		return l;
	}
}

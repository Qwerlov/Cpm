package com.oleo.cpmscripts.gui;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** Общий стиль GUI cpmscripts: тёмные панели + бирюзовый акцент (в духе CPM). */
public final class GuiStyle {
	private GuiStyle() {}

	public static final int BG           = 0xF014151C;
	public static final int HEADER       = 0xFF1B1D27;
	public static final int PANEL        = 0xFF1E2029;
	public static final int PANEL_BORDER = 0xFF343746;
	public static final int ACCENT       = 0xFF5BC0BE;
	public static final int BTN          = 0xFF2A2D3A;
	public static final int BTN_HOVER    = 0xFF3A3E50;
	public static final int BTN_DISABLED = 0xFF22242E;
	public static final int BTN_BORDER   = 0xFF454A5E;
	public static final int TEXT         = 0xFFE8EAF0;
	public static final int MUTED        = 0xFF9AA0B0;
	public static final int ERROR        = 0xFFFF6B6B;
	public static final int ON           = 0xFF7BD88F;

	/** Тёмный фон экрана. */
	public static void background(GuiGraphics gg, int w, int h) {
		gg.fill(0, 0, w, h, BG);
	}

	/** Шапка: полоса + заголовок + акцентная линия. */
	public static void header(GuiGraphics gg, Font font, int w, String title, String subtitle) {
		gg.fill(0, 0, w, 26, HEADER);
		gg.fill(0, 26, w, 28, ACCENT);
		Component titleComponent = Component.literal(title).withStyle(s -> s.withColor(ACCENT & 0xFFFFFF).withBold(true));
		gg.drawString(font, titleComponent, 10, 9, TEXT);
		if (subtitle != null && !subtitle.isEmpty()) {
			// ширина считается по тому же стилю, что и рисуется — иначе подзаголовок съезжает
			int tw = font.width(titleComponent);
			gg.drawString(font, subtitle, 10 + tw + 4, 9, MUTED);
		}
	}

	/** Панель с рамкой. */
	public static void panel(GuiGraphics gg, int x, int y, int w, int h) {
		gg.fill(x, y, x + w, y + h, PANEL);
		gg.fill(x, y, x + w, y + 1, PANEL_BORDER);
		gg.fill(x, y + h - 1, x + w, y + h, PANEL_BORDER);
		gg.fill(x, y, x + 1, y + h, PANEL_BORDER);
		gg.fill(x + w - 1, y, x + w, y + h, PANEL_BORDER);
	}

	/** Тонкая разделительная линия. */
	public static void divider(GuiGraphics gg, int x, int y, int w) {
		gg.fill(x, y, x + w, y + 1, PANEL_BORDER);
	}
}

package com.oleo.cpmscripts.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Просмотр текста (сгенерированный Lua) с прокруткой. */
public class TextViewScreen extends Screen {
	private final Screen parent;
	private final String title;
	private final String text;
	private int scroll;

	public TextViewScreen(Screen parent, String title, String text) {
		super(Component.literal(title));
		this.parent = parent;
		this.title = title;
		this.text = text;
	}

	@Override
	protected void init() {
		addRenderableWidget(new FlatButton(this.width - 76, this.height - 24, 70, 18,
				Component.literal("Назад"), b -> onClose()));
	}

	@Override
	public void render(GuiGraphics gg, int mouseX, int mouseY, float partialTick) {
		GuiStyle.background(gg, this.width, this.height);
		GuiStyle.header(gg, this.font, this.width, title, "колесо — прокрутка");
		String[] lines = text.split("\n", -1);
		int y = 34 - scroll;
		for (String line : lines) {
			if (y > 8 && y < this.height - 28)
				gg.drawString(this.font, line, 10, y, line.startsWith("--") ? GuiStyle.MUTED : GuiStyle.TEXT);
			y += 11;
		}
		super.render(gg, mouseX, mouseY, partialTick);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double sx, double sy) {
		scroll = (int) Math.max(0, Math.min(Math.max(0, text.split("\n").length * 11 - this.height + 60), scroll - sy * 15));
		return true;
	}

	@Override
	public void onClose() {
		Minecraft.getInstance().setScreen(parent);
	}

	@Override
	public boolean isPauseScreen() { return false; }
}
